#!/usr/bin/env python3
"""Lee el Texto Madre como DATOS (PALABRA, MORF, SINT, CONC, USO, ROSETTA, REGLA), verifica que sus
propios ejemplos cumplan sus reglas y descubre patrones en su prosa que ninguna regla cubre.
Uso: python madre_patrones.py [TEXTO_MADRE_DELTA_v5.md]"""
import json, re, os, sys, importlib, collections as C
AQUI = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, AQUI)
CAT = {"articulo": "ART", "pronombre": "PRON", "posesivo": "POS", "demostrativo": "DEM", "interrogativo": "INT",
       "preposicion": "PREP", "conjuncion": "CONJ", "adjetivo": "ADJ", "adverbio": "ADV", "verbo": "V",
       "sustantivo": "N", "madre": "N", "conversacion": "CONV", "relativo": "CONJ"}
TOK = re.compile(r"[a-záéíóúñü]+|[.,;:¿?¡!…]", re.I)
def toks(t): return [x.lower() for x in TOK.findall(t) if x.isalpha() or x[0] in "áéíóúñüabcdefghijklmnopqrstuvwxyz"]
def cat_de(c):
    for k, v in CAT.items():
        if c.startswith(k): return v
    return "?"

def leer(md):
    d = C.defaultdict(list)
    for l in open(md, encoding="utf8"):
        p = [x.strip() for x in l.rstrip("\n").split("|")]
        if p[0] in ("PALABRA", "MORF", "SINT", "CONC", "USO", "ROSETTA"): d[p[0]].append(p[1:])
    return d

def construir_lexico(d):
    lex = {w: {"cat": cat_de(e["cat"]), "firma": e["firma"], "r": set()} for w, e in
           json.load(open(os.path.join(AQUI, "lexico_delta.json"), encoding="utf8")).items()}
    lemas = {}
    for f, cat, firma, r in d["PALABRA"]:
        e = lex.setdefault(f, {"cat": cat, "firma": firma, "r": set()}); e["cat"] = cat; e["r"] = set(r.split())
        if firma != "?": e["firma"] = firma
        lemas[f] = e
    return lex, lemas

def _cond(c, f, r):
    if c in ("ar", "er", "ir"): return f.endswith(c)
    if c == "v": return f[-1] in "aeiouáéíóú"
    if c == "c": return f[-1] not in "aeiouáéíóúz"
    if c == "z": return f.endswith("z")
    if c == "fx": return "fx" in r
    return True

def aplicar(fila, forma, rasgos=frozenset()):
    clase, q, p = fila[0], fila[1], fila[2]
    ini, _, fin = clase.partition(">"); cats, _, c = ini.partition(":")
    if not _cond(c, forma, rasgos): return None
    if q != "-":
        if not forma.endswith(q): return None
        forma = forma[:-len(q)]
    return forma + p

def generar_formas(lex, lemas, morf):
    """forma -> [(lema, cat, rasgos, efecto Δ)] a partir de los lemas de la Madre y las filas MORF."""
    out = C.defaultdict(list)
    for lema, e in lemas.items():
        if e["cat"] not in ("N", "ADJ", "V"): continue
        base = [(lema, set(e["r"]), "-")]
        for f in morf:
            if f[0].partition(">")[2] or "pl" in f[3].split() or "f" not in f[3].split(): continue
            if e["cat"] in f[0].partition(":")[0].split(","):  # género
                for fm, r, _ in list(base):
                    n = aplicar(f, fm, e["r"])
                    if n: base.append((n, (r - {"m"}) | {"f"}, "-"))
        formas = list(base)
        for f in morf:
            cats = f[0].partition(">")[0].partition(":")[0].split(","); dest = f[0].partition(">")[2]
            if e["cat"] not in cats: continue
            if "pl" in f[3].split():
                for fm, r, _ in base:
                    n = aplicar(f, fm, e["r"])
                    if n: formas.append((n, (r - {"sg"}) | {"pl"}, "-"))
            elif dest:
                for fm, r, _ in base:
                    n = aplicar(f, fm, e["r"])
                    if n: out[n].append((lema, "ADV", {"modo"}, f[4]))
            elif e["cat"] == "V":
                n = aplicar(f, lema)
                if n: out[n].append((lema, "V", set(f[3].split()), f[4]))
        for fm, r, dl in formas: out[fm].append((lema, e["cat"], r, dl))
    return out

def etiquetar(w, lex, gen):
    """(categoría, rasgos, origen) de una palabra."""
    if w in lex: return lex[w]["cat"], lex[w]["r"], "léxico"
    if w in gen: l, c, r, _ = gen[w][0]; return c, r, "morfología"
    return "?", set(), "desconocida"

def posibles(w, lex, gen):
    """Todas las categorías que una palabra puede tener (como/V·ADV, vivo/V·ADJ)."""
    c = {lex[w]["cat"]} if w in lex else set()
    c |= {x[1] for x in gen.get(w, [])}
    return c or {"?"}

def verificar_morf(d):
    mal = []
    for f in d["MORF"]:
        for par in f[5].split(";"):
            a, _, b = par.strip().partition(">")
            if aplicar(f, a, {"fx"}) != b: mal.append((f[0], f[1], f[2], par.strip(), aplicar(f, a, {"fx"})))
    return sum(len(f[5].split(";")) for f in d["MORF"]), mal

def verificar_sint(d, lex, gen):
    n = 0; mal = []
    for _, pat, nom, ej in d["SINT"]:
        for fr in ej.split(";"):
            t = toks(fr); n += 1; p = pat.split(); c = [sorted(posibles(w, lex, gen)) for w in t]
            if len(c) != len(p) or any(x not in y for x, y in zip(p, c)): mal.append((fr.strip(), pat, c))
    return n, mal

def verificar_conc(frase, lex, gen):
    g, nu = set(), set()
    for w in toks(frase):
        c, r, _ = etiquetar(w, lex, gen)
        if c not in ("ART", "DEM", "N", "ADJ"): continue
        g |= r & {"m", "f"}; nu |= (r & {"pl"}) or ({"sg"} if r & {"m", "f"} or c == "N" else set())
    return len(g) <= 1 and len(nu) <= 1

def verificar_rosetta(d, lex):
    mal = []
    for dl, esp, ej, cod in d["ROSETTA"]:
        try:
            o = importlib.import_module(cod.split(".")[0])
            for a in cod.split(".")[1:]: o = getattr(o, a)
        except Exception as e: mal.append((dl, cod, "no existe en el código")); continue
        if dl.startswith("Ξ") and ej in lex and sorted(re.findall(r"[^\s{}]+", lex[ej]["firma"])) != sorted(re.findall(r"[^\s{}]+", dl)): mal.append((dl, ej, f"el léxico dice {lex[ej]['firma']}"))
    return len(d["ROSETTA"]), mal

def descubrir(md, d, lex, gen, top=8):
    import semilla_delta as S
    pats = [p.split() for _, p, _, _ in d["SINT"]]; cub = {(a, b) for p in pats for a, b in zip(p, p[1:])}
    bi = C.Counter()
    for s in S.frases(open(md, encoding="utf8").read()):
        c = [etiquetar(w, lex, gen)[0] for w in s if w.isalpha()]
        if c.count("?") / max(len(c), 1) > .4: continue
        bi.update((a, b) for a, b in zip(c, c[1:]) if "?" not in (a, b))
    return [(k, v) for k, v in bi.most_common() if k not in cub][:top]

if __name__ == "__main__":
    md = sys.argv[1] if len(sys.argv) > 1 else os.path.join(AQUI, "TEXTO_MADRE_DELTA_v5.md")
    d = leer(md); lex, lemas = construir_lexico(d); gen = generar_formas(lex, lemas, d["MORF"])
    print(f"Madre leído: {len(d['PALABRA'])} palabras definidas, {len(d['MORF'])} reglas morfológicas ({len(gen)} formas generadas), "
          f"{len(d['SINT'])} patrones sintácticos, {len(d['CONC'])} de concordancia, {len(d['USO'])} de uso, {len(d['ROSETTA'])} filas Rosetta")
    n, mal = verificar_morf(d); print(f"\nMORF: {n-len(mal)}/{n} ejemplos reproducidos por su regla"); [print("  ✗", m) for m in mal]
    n, mal = verificar_sint(d, lex, gen); print(f"\nSINT: {n-len(mal)}/{n} ejemplos encajan en su patrón"); [print("  ✗", m) for m in mal]
    ok = bad = 0; fallos = []
    for _, reg, ej, contra in d["CONC"]:
        for fr in ej.split(";"):
            if verificar_conc(fr, lex, gen): ok += 1
            else: fallos.append(("debía concordar", fr.strip()))
        for fr in contra.split(";"):
            if not verificar_conc(fr.strip().lstrip("*"), lex, gen): bad += 1
            else: fallos.append(("debía fallar", fr.strip()))
    print(f"\nCONC: {ok} ejemplos concuerdan, {bad} contraejemplos rechazados, {len(fallos)} fallos"); [print("  ✗", f) for f in fallos]
    desc = C.Counter()
    for sec in ("USO",):
        for f in d[sec]:
            for col in f[3:5]:
                for fr in col.split(";"):
                    for w in toks(fr.lstrip("* ")):
                        if etiquetar(w, lex, gen)[2] == "desconocida": desc[w] += 1
    for sec in ("SINT",):
        for f in d[sec]:
            for fr in f[3].split(";"):
                for w in toks(fr):
                    if etiquetar(w, lex, gen)[2] == "desconocida": desc[w] += 1
    print(f"\nVOCABULARIO de los ejemplos: {len(desc)} palabras sin definir en el Madre", (list(desc)[:15] if desc else ""))
    n, mal = verificar_rosetta(d, lex); print(f"\nROSETTA: {n-len(mal)}/{n} filas coherentes con el código y el léxico"); [print("  ✗", m) for m in mal]
    print("\nPATRONES en la prosa del Madre que ninguna regla SINT cubre (par de categorías, frecuencia):")
    for k, v in descubrir(md, d, lex, gen): print(f"  {k[0]} → {k[1]}: {v}")
