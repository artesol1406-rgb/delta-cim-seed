#!/usr/bin/env python3
"""CIM de dos mentes: el corpus entra siguiendo el ritmo del Códice (no todo de golpe).
  Mente R (receptiva-dinámica) = contenedor: RECIBE (mide la sorpresa de lo que entra), abre la superposición y la COLAPSA (colapso retroactivo).
  Mente A (activa-estática)    = nodo contenido: GUARDA (cuentas, clases comprometidas, reglas) y se expande hasta la METAESTABILIDAD.
Ritmo 1 (codex): los cantos en orden de respiración P E P C P E P C P E P.   Ritmo 2 (canto): cada sección es un ciclo e1→e5.
Ciclo:  e1 emitir (entra a R) · e2 fijar: el polo estático de A SE CONTRAE (descomete clases de palabras vistas una sola vez; guarda la regla)
        e3 explorar: el contenedor SE EXPANDE (entran las preguntas; se mide la superposición abierta)
        e4 el contenedor SE CONTRAE: colapso retroactivo de clases latentes y lo recibido se GUARDA en A
        e5 el nodo SE EXPANDE hasta la metaestabilidad (la pérdida y la varianza dejan de moverse) → empieza el ciclo siguiente.
Medidas (todas sobre lo que aún NO está guardado = fuera de muestra): sorpresa (pérdida), pérdida retroactiva, varianza antes→después del colapso.
Uso: python entrenar_cim.py [TEXTO_MADRE_DELTA_v5.md]   (requiere entrenar_semilla.py, ritmo_corpus.py y los módulos del Madre)"""
import os, sys, math, random, collections as C
AQUI = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, AQUI)
import entrenar_semilla as E
from ritmo_corpus import CANTO_FASE, ROMANO, PASOS

def medir(S, cnt, chunk, rng, pesos=None):
    """Pérdida hacia delante, retroactiva y varianza antes→después del colapso, de `chunk` con las cuentas `cnt`."""
    R = C.defaultdict(list); viejo = S.m
    if pesos: S.m = pesos
    try:
        for cn, t, peso, _ in chunk:
            if len(t) < 2: continue
            ctxs = S.contextos(t)
            for j in range(len(t)):
                lf, lr, hpre, hpost, rf, rr = S.posicion(cnt, t, ctxs, j, rng)
                R["lf"].append(lf); R["hpre"].append(hpre)
                if lr is not None: R["lr"].append(lr); R["hpost"].append(hpost)
    finally: S.m = viejo
    mean = lambda x: sum(x) / len(x) if x else float("nan")
    return {k: mean(v) for k, v in R.items()}

def comprometidas(S): return sum(1 for w, c in S.LAT.items() if c != S.LAT0.get(w))

def metaestabilidad(S, guardado, rng, maxep=8):
    """El nodo A se expande hasta que pérdida retroactiva y varianza dejan de moverse (|Δ| < 3e-3 dos veces)."""
    prev = None; quieto = 0; n = 0
    for n in range(1, maxep + 1):
        S.mm = E.ajustar_pesos(S, guardado, S.mm, insample=True)
        mi = E.evaluar(S, guardado, paso=4, insample=True, pesos=S.mm)
        if prev and abs(prev["lr"] - mi["lr"]) < 3e-3 and abs(prev["hpre"] - mi["hpre"]) < 3e-3: quieto += 1
        else: quieto = 0
        prev = mi
        if quieto >= 2 and n >= 3: break
    if len(guardado) >= 2 * E.K_PLIEGUES: S.m = E.ajustar_pesos(S, guardado, S.m, insample=False)
    return n, prev

def correr(M, log=print, seed=0):
    S = E.Semilla(M); S.mm = [.2] * 5; S.LAT0 = dict(S.LAT); rng = random.Random(seed)
    ciclos = C.OrderedDict()                                     # (canto, sección) → modo → frases, en el orden del Códice
    for fr, (sec, modo) in zip(M.frases, M.meta): ciclos.setdefault((fr[0], sec), C.OrderedDict()).setdefault(modo, []).append(fr)
    guardado = []; buffer = []; filas = []
    for (canto, sec), modos in ciclos.items():
        fase = CANTO_FASE[canto]; ultimo = list(modos)[-1]
        for modo, chunk in modos.items():
            paso = PASOS[modo][0] if modo else "bloque"
            sor = medir(S, S.construir(guardado), chunk, rng) if len(guardado) >= 10 else None      # lo que ENTRA, fuera de muestra
            fila = dict(canto=canto, fase=fase, sec=sec, modo=modo, paso=paso, n=len(chunk), guardado=len(guardado), sorpresa=sor)
            if modo == 1: buffer += chunk                                                              # R recibe la afirmación
            elif modo == 2:                                                                            # A: el polo estático anidado se contrae
                guardado += chunk; cuenta = C.Counter(w for _, t, _, _ in guardado for w in t); antes = comprometidas(S)
                for w in list(S.LAT):
                    if cuenta[w] == 1: S.LAT[w] = S.LAT0[w]
                fila["contrae_A"] = (antes, comprometidas(S))
            elif modo == 3: buffer += chunk                                                            # el contenedor se expande: entran las preguntas
            elif modo == 4 or modo == 0:                                                               # el contenedor se contrae y guarda en A
                todo = guardado + buffer + chunk; ch = E.colapsar_latentes(S, todo); guardado = todo; buffer = []
                fila["colapso"] = ch; fila["guardado_tras"] = medir(S, S.construir(guardado), chunk, rng)
            if modo == 5 or modo == 0 or (modo == 4 and modo == ultimo):                               # A se expande hasta la metaestabilidad
                if modo == 5: guardado += chunk
                if buffer: guardado += buffer; buffer = []
                ep, mi = metaestabilidad(S, guardado, rng); fila["meta"] = (ep, mi["lr"], mi["hpre"], "implícita" if modo != 5 else "geodésica")
            filas.append(fila)
    return S, filas

def informe(filas, log=print):
    log(f"{'canto':>5} {'fase':>4} {'sec':>3} {'paso':>20} {'n':>3} {'guard.':>6} | ENTRA (fuera de muestra) pérdida retro varianza pre→post | tras guardar retro | metaestabilidad (épocas, retro, var)")
    for f in filas:
        s = f["sorpresa"]; ent = f"{s['lf']:6.2f} {s['lr']:6.2f}  {s['hpre']:.2f}→{s['hpost']:.2f}" if s and "lr" in s and s["lr"] == s["lr"] else "      —"
        g = f.get("guardado_tras"); tg = f"{g['lr']:.2f}" if g else "  —"
        m = f.get("meta"); tm = f"{m[0]} ép, {m[1]:.2f}, {m[2]:.2f} ({m[3]})" if m else ""
        log(f"{ROMANO[f['canto']-1]:>5} {f['fase']:>4} {f['sec']:>3} {f['paso']:>20} {f['n']:>3} {f['guardado']:>6} | {ent:36s} | {tg:>5} | {tm}")

def resumen(filas, S, M, log=print):
    por_modo = C.defaultdict(list)
    for f in filas:
        s = f["sorpresa"]
        if s and s.get("lr") == s.get("lr") and f["modo"]: por_modo[f["modo"]].append(s)
    log("\nSORPRESA POR PASO (lo que entra, fuera de muestra; media sobre ciclos):")
    for m in sorted(por_modo):
        v = por_modo[m]; mn = lambda k: sum(x[k] for x in v) / len(v)
        log(f"  e{m} {PASOS[m][0]:20s} n={len(v):2d}  pérdida {mn('lf'):.2f}  retro {mn('lr'):.2f}  varianza antes {mn('hpre'):.2f} → después {mn('hpost'):.2f}")
    por_fase = C.defaultdict(list)
    for f in filas:
        s = f["sorpresa"]
        if s and s.get("lr") == s.get("lr"): por_fase[f["fase"]].append(s["lr"])
    log("SORPRESA RETROACTIVA POR FASE DEL CANTO (flujo general): " + "  ".join(f"{k} {sum(v)/len(v):.2f} (n={len(v)})" for k, v in sorted(por_fase.items())))
    cic = [f for f in filas if f.get("meta")]; log(f"METAESTABILIDAD: {len(cic)} ciclos; épocas hasta quedar quieto {[f['meta'][0] for f in cic]}; "
        f"implícitas (sin geodésica): {sum(1 for f in cic if f['meta'][3]=='implícita')}")
    c2 = [f["contrae_A"] for f in filas if f.get("contrae_A")]
    if c2: log(f"MENTE A contrae (e2): clases comprometidas antes→después por ciclo {[(a, b) for a, b in c2]}")
    mi = E.evaluar(S, M.frases, paso=2, insample=True, pesos=S.mm); cv = E.evaluar(S, M.frases, paso=4)
    log(f"FINAL  maestría  pérdida {mi['lf']:.3f} retro {mi['lr']:.3f} varianza {mi['hpre']:.3f}→{mi['hpost']:.3f} top5 {mi['r5']:.2f}")
    log(f"FINAL  generalización (5 pliegues) pérdida {cv['lf']:.3f} retro {cv['lr']:.3f} varianza {cv['hpre']:.3f}→{cv['hpost']:.3f}")
    return mi, cv

if __name__ == "__main__":
    md = next((a for a in sys.argv[1:] if not a.startswith("--")), os.path.join(AQUI, "TEXTO_MADRE_DELTA_v5.md")); M = E.Madre(md)
    S, filas = correr(M); informe(filas); resumen(filas, S, M)
