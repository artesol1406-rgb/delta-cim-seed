#!/usr/bin/env python3
"""NÚCLEO Δ — un solo objeto que une Semilla + CIM (Mente/Cuerpo) + memoria HRR.  main.py y servidor.py solo lo llaman.

  Semilla   cuentas del Madre (v5), clases latentes, colapso retroactivo        (entrenar_semilla.py, crecer.py)
  Mente     solo lectura: probabilidades, estado sintáctico, n efectivo          (cim.py)
  Cuerpo    sostiene huecos y los colapsa hacia atrás con el contexto derecho    (cim.py)
  HRR       memoria holográfica de dos niveles (palabra, estado) con numpy.fft   (memoria_hrr.py)
Política por posición: PREDICE si P ≥ τ · PREDICE CLASE · ABRE (espera) · RETRO (piensa hacia atrás)."""
import os, sys, json, random
AQUI = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, AQUI)
import entrenar_semilla as E, cim, crecer as K, memoria_hrr as H

MD = os.path.join(AQUI, "TEXTO_MADRE_DELTA_v5.md"); PKL = os.path.join(AQUI, "semilla_R.pkl"); EXTRA = os.path.join(AQUI, "memoria_extra.json")
HUECO = "zzhueco"                                    # el símbolo ▢ viaja como palabra desconocida y se colapsa hacia atrás

class Delta:
    def __init__(s, log=print, tau=0.90):
        s.log, s.tau, s.rng = log, tau, random.Random(0)
        if os.path.exists(PKL) and os.path.getmtime(PKL) >= os.path.getmtime(MD):
            log("cargando la semilla guardada…"); s.S, _ = E.cargar(MD, PKL)
        else:
            log("entrenando la semilla con el Madre v5 (una sola vez; ~1 min)…"); s.S, _, h = E.entrenar(MD, log=lambda *a: None); E.guardar(s.S, h, PKL)
        s.base = list(s.S.M.frases); s.extras = []
        if os.path.exists(EXTRA):
            for t in json.load(open(EXTRA, encoding="utf8")): s._absorber([t], guardar=False)
        s._rehacer()
    # ── piezas ──
    def _rehacer(s):
        s.cnt = s.S.construir(s.base); s.mente = cim.Mente(s.S, s.cnt, s.S.m); s.cuerpo = cim.Cuerpo()
        s.hrr = H.MemoriaFractal(lambda w: "|".join(str(x) for x in s.S.estado(w)))
        s.hrr.entrena([t for _, t, _, _ in s.base])
    def _absorber(s, frases, guardar=True):
        tanda = [(99, E.cerrar(t), 1, "extra") for t in frases if len(t) >= 2]
        if tanda: s.base = K.absorber(s.S, s.base, tanda); s.extras += [t for _, t, _, _ in tanda]
        if guardar: json.dump(s.extras, open(EXTRA, "w", encoding="utf8"), ensure_ascii=False)
    # ── API ──
    def procesar(s, texto, tau=None):
        tau = s.tau if tau is None else tau; texto = texto.replace("▢", " " + HUECO + " ")
        t = E.cerrar(E.toks(texto)); filas = []; s.cuerpo.huecos = []
        for i, w in enumerate(t):
            f = {"i": i, "w": "▢" if w == HUECO else w}
            if w in E.PUNT: f["accion"] = "puntuación"; filas.append(f); continue
            try:
                lec = s.mente.lee(t, i, s.rng); a = cim.decidir(lec, tau_w=tau)
                hrr = s.hrr.puntua(t[:i], 3)
                f.update(accion=a, pw=round(lec["pw"], 3), neff=round(lec["neff"], 1), estado="|".join(str(x) for x in lec["st"]), pst=round(lec["pst"], 3),
                         top=[(x, round(lec["P"][x] / lec["tot"], 3)) for x in lec["top"][:3]], hrr=[(x, round(c, 2)) for x, c in hrr["palabras"]],
                         hrr_clase=hrr["clase"][0] if hrr["clase"] else None, consenso=bool(hrr["palabras"]) and hrr["palabras"][0][0] == lec["top"][0])
                if w == HUECO: f["accion"] = "hueco"; s.cuerpo.abre(i)
                if "retro" in lec: f["retro"] = [x for x in s.cuerpo.colapsa(lec) if x != HUECO][:3]
                f["oov"] = w != HUECO and w not in s.cnt.V
            except Exception as e: f.update(accion="desconocida", error=type(e).__name__)
            filas.append(f)
        return {"tokens": filas, "respuesta": s.continuar(t, tau), "tau": tau}
    def continuar(s, t, tau):
        """Emite solo mientras la semilla esté cerca de la certeza; al primer punto incierto se detiene y dice por qué."""
        ctx = [w for w in t if w != HUECO]
        while ctx and ctx[-1] in E.PUNT: ctx.pop()
        out = []
        for _ in range(12):
            try: lec = s.mente.lee(ctx + ["."], len(ctx), s.rng)
            except Exception: break
            if lec["pw"] < tau: return {"texto": " ".join(out), "espera": {"pw": round(lec["pw"], 3), "neff": round(lec["neff"], 1), "estado": "|".join(str(x) for x in lec["st"])}}
            w = lec["top"][0]; out.append(w); ctx.append(w)
            if w in E.PUNT: break
        return {"texto": " ".join(out), "espera": None}
    def crecer(s, texto):
        fr = [x for x in E.SD.frases(" ".join(texto.split())) if len(x) >= 3]; s._absorber(fr); s._rehacer(); return {"frases": len(fr), "vocabulario": len(s.cnt.V)}
    def estado(s):
        return {"frases_madre": len(s.S.M.frases), "frases_extra": len(s.extras), "vocabulario": len(s.cnt.V), "pesos_mezcla": [round(x, 2) for x in s.S.m],
                "hrr_pares": s.hrr.L0.n, "hrr_D": s.hrr.L0.D, "tau": s.tau}
    def evaluar_hrr(s): return H.evaluar([t for _, t, _, _ in s.S.M.frases], None)
