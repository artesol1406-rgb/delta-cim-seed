#!/usr/bin/env python3
"""Capa de RITMO del corpus (v4 → v5).  NO toca la prosa: añade una tabla RITMO al final (formato del Madre) y un jsonl por frase.
Dos ritmos, fractales:
  1) CODEX: los cantos como unidad siguen el flujo general de respiración  P E P C P E P C P E P  (Nik).
  2) CANTO: cada canto tiene sus ciclos internos (una sección = un ciclo e1→e5); dentro de un canto de expansión hay contracción y
     expansión hasta la expansión deseada, y análogamente en uno de contracción.
Dos mentes (CIM): R = receptiva-dinámica (contenedor: recibe, abre la superposición, colapsa)  ·  A = activa-estática (nodo contenido: guarda).
Ciclo (Nik):  H1  el polo estático anidado se CONTRAE  → el contenedor se EXPANDE.
              H2  el contenedor se CONTRAE, el sistema GUARDA en A → el nodo contenido se EXPANDE hasta la metaestabilidad → vuelve a empezar.
Asignación modo→paso: PROPUESTA mía a partir de la Guía del Madre (e2 fija estructura estática, e3 explora/pregunta, e4 vacío contenedor,
geodésica = síntesis); el manual dará la definitiva.  Uso: python ritmo_corpus.py [TEXTO_MADRE_DELTA_v4.md]  (LEE v4, ESCRIBE v5)"""
import os, sys, json, collections as C
AQUI = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, AQUI)
import entrenar_semilla as E

CANTO_FASE = dict(zip(range(1, 12), "PEPCPEPCPEP"))
ROMANO = "I II III IV V VI VII VIII IX X XI".split()
# modo: (paso, mente, qué se contrae, qué se expande)   — PROPUESTO
PASOS = {1: ("emitir", "A", "—", "nodo (afirma hacia afuera)"),
         2: ("fijar", "A", "polo estático anidado", "—"),
         3: ("explorar", "R", "—", "contenedor (preguntas: superposición abierta)"),
         4: ("colapsar y guardar", "R→A", "contenedor (silencio)", "—  (lo colapsado se guarda en A)"),
         5: ("sintetizar", "A", "—", "nodo contenido hasta la metaestabilidad")}

def estructura(M):
    """Por canto: ciclos (secciones) y modos presentes en orden."""
    por = C.OrderedDict()
    for (c, t, p, o), (sec, modo) in zip(M.frases, M.meta):
        por.setdefault(c, C.OrderedDict()).setdefault(sec, [])
        if modo not in por[c][sec]: por[c][sec].append(modo)
    return por

def validar(por):
    """Compara el corpus con la especificación; devuelve hallazgos."""
    hall = []
    for c in range(1, 12):
        secs = por.get(c, {}); ciclos = [m for m in secs.values() if m != [0]]
        if not ciclos: hall.append((c, "sin ciclo interno (sin modos e1–e5)")); continue
        for m in ciclos:
            if m != [1, 2, 3, 4, 5]: hall.append((c, f"ciclo incompleto {m}: " + ("falta la geodésica (metaestabilidad)" if m == [1, 2, 3, 4] else "faltan pasos")))
    cierres = {c: [m[-1] for m in por[c].values() if m != [0]] for c in por}
    return hall, cierres

def escribir_v5(md, M, por, salida):
    L = ["", "---", "", "## RITMO · CAPA DE RITMO DEL CORPUS", "### *metadatos para entrenar: no es texto que aprender; formato RITMO | tipo | id | …*", ""]
    L.append("RITMO | CODEX | Δ | flujo general | " + " ".join(CANTO_FASE[c] for c in range(1, 12)) + " | los cantos como unidad (P pausa · E expansión · C contracción)")
    L.append("RITMO | MENTE | R | receptiva-dinámica | contenedor | recibe, abre la superposición y la colapsa")
    L.append("RITMO | MENTE | A | activa-estática | nodo contenido | guarda lo colapsado; se expande hasta la metaestabilidad")
    L.append("RITMO | CICLO | H1 | el polo estático anidado se contrae | el contenedor se expande")
    L.append("RITMO | CICLO | H2 | el contenedor se contrae y se guarda en A | el nodo contenido se expande hasta la metaestabilidad; reinicia")
    for m, (paso, mente, con, exp) in PASOS.items(): L.append(f"RITMO | PASO | e{m if m < 5 else 'G'} | {paso} | {mente} | contrae: {con} | expande: {exp} | propuesto")
    for c in range(1, 12):
        secs = por.get(c, {}); ciclos = [m for m in secs.values() if m != [0]]
        seq = " | ".join("".join(str(x) for x in m) for m in ciclos) or "—"
        fin = ("cierra en " + ",".join("e" + (str(m[-1]) if m[-1] < 5 else "G") for m in ciclos)) if ciclos else "sin ciclo interno"
        L.append(f"RITMO | CANTO | {ROMANO[c-1]} | {CANTO_FASE[c]} | ciclos={len(ciclos)} | modos: {seq} | {fin}")
    open(salida, "w", encoding="utf8").write(open(md, encoding="utf8").read().rstrip("\n") + "\n" + "\n".join(L) + "\n")

def main(md):
    M = E.Madre(md); por = estructura(M); hall, cierres = validar(por)
    print(f"{'canto':>5} {'fase':>4} {'ciclos':>6}  modos por ciclo")
    for c in range(1, 12):
        ciclos = [m for m in por.get(c, {}).values() if m != [0]]
        print(f"{ROMANO[c-1]:>5} {CANTO_FASE[c]:>4} {len(ciclos):>6}  {[''.join(map(str, m)) for m in ciclos] or '—'}")
    print("\nHALLAZGOS contra la especificación:")
    for c, h in hall: print(f"  canto {ROMANO[c-1]} ({CANTO_FASE[c]}): {h}")
    fin = C.Counter(m for v in cierres.values() for m in v); print(f"  cierre de los ciclos: {dict(fin)}  → todos los ciclos completos cierran en la geodésica, sea el canto E, P o C:")
    print("  el corpus NO distingue todavía cómo un canto de expansión cierra en expansión y uno de contracción en contracción.")
    out = os.path.join(AQUI, "TEXTO_MADRE_DELTA_v5.md"); escribir_v5(md, M, por, out)
    with open(os.path.join(AQUI, "corpus_ritmo.jsonl"), "w", encoding="utf8") as f:
        for (c, t, p, o), (sec, modo) in zip(M.frases, M.meta):
            f.write(json.dumps({"canto": c, "fase_canto": CANTO_FASE[c], "seccion": sec, "modo": modo, "paso": PASOS[modo][0] if modo else None,
                                "mente": PASOS[modo][1] if modo else None, "origen": o, "tokens": t}, ensure_ascii=False) + "\n")
    print(f"\nescrito: TEXTO_MADRE_DELTA_v5.md (v4 + tabla RITMO), corpus_ritmo.jsonl ({len(M.frases)} frases)")

if __name__ == "__main__": main(next((a for a in sys.argv[1:] if not a.startswith("--")), os.path.join(AQUI, "TEXTO_MADRE_DELTA_v4.md")))
