#!/usr/bin/env python3
"""Semilla Δ — modelo de lenguaje que aprende en línea.
Mezcla bayesiana de 4 predictores: unigrama, bigrama, trigrama de palabras y un modelo de CLASES
donde la clase de cada palabra es su firma Δ (léxico + reglas del Texto Madre). Al inicio manda la
estructura (clases); con más datos mandan las palabras. Interfaz estable: predict(contexto)->distribución,
para poder cambiar el motor interno (etapa neuronal) sin tocar el resto.
Uso: train ARCHIVO...  |  eval ARCHIVO  |  gen "texto" [n]  |  chat
Solo biblioteca estándar."""
import json, re, math, random, sys, os, pickle, collections as C
AQUI = os.path.dirname(os.path.abspath(__file__)); ESTADO = os.path.join(AQUI, "semilla_estado.pkl")
TOK = re.compile(r"[a-záéíóúñü]+|[.,;:¿?¡!…]", re.I)
RG = re.compile(r"^\s*>?\s*REGLA\s+(\S+)\s*\|\s*prev:(\S+)\s*\|\s*next:(\S+)\s*\|\s*(Ξ\{[^}]*\})\s*\|")
def tokenizar(t): return [x.lower() for x in TOK.findall(t)]
def frases(txt):
    txt = re.sub(r"\$[^$]*\$", " ", txt); out = []
    for l in txt.split("\n"):
        if "REGLA" in l or l.strip().startswith("Formato:"): continue
        l = re.sub(r"[`*#>|_\\]|^\s*[-\d]+[.)]?\s", " ", l)
        for s in re.split(r"(?<=[.?!…])\s+", l):
            t = tokenizar(s)
            if len(t) >= 3: out.append(t)
    return out

class Semilla:
    def __init__(s, lexico=None, reglas=None):
        s.lex = {w: e["firma"] for w, e in (lexico or {}).items()}; s.cat = {w: e["cat"] for w, e in (lexico or {}).items()}
        s.reglas = reglas or []; s.apr = {}; s.pend = C.Counter()
        s.N = 0; s.V = set(); s.F = set()
        s.w1 = C.Counter(); s.w2 = C.defaultdict(C.Counter); s.w3 = C.defaultdict(C.Counter)
        s.f2 = C.defaultdict(C.Counter); s.em = C.defaultdict(C.Counter)
        s.n2 = C.Counter(); s.n3 = C.Counter(); s.nf = C.Counter(); s.ne = C.Counter()
        s.mix = [0.25] * 4; s.hist = []
    # ── firma de una palabra ──
    def _m(s, tok, spec):
        if spec == "*": return True
        if spec == "-": return tok is None
        if tok is None: return False
        return any(tok == x or s.cat.get(tok, "").startswith(x) for x in spec.split(","))
    def firma(s, w, prev=None, nxt=None, aprender=False):
        if w in ".,;:¿?¡!…": return "Ξ"
        if w in s.lex: return s.lex[w]
        if w in s.apr: return s.apr[w]
        for r in s.reglas:
            if s._m(prev, r["prev"]) and s._m(nxt, r["next"]):
                if aprender: s.apr[w] = r["firma"]
                return r["firma"]
        if aprender: s.pend[w] += 1
        return "?"
    def cls(s, w): return "Ξ" if w in ".,;:¿?¡!…" else s.lex.get(w) or s.apr.get(w) or "?"
    # ── componentes ──
    def p0(s, w): return (s.w1[w] + 0.1) / (s.N + 0.1 * (len(s.V) + 5000))
    def comps(s, w, pp, p, fp):
        a = 1.0; u = s.p0(w)
        b = (s.w2[p][w] + a * u) / (s.n2[p] + a) if s.n2[p] else u
        t = (s.w3[(pp, p)][w] + a * b) / (s.n3[(pp, p)] + a) if s.n3[(pp, p)] else b
        fw = s.cls(w); pf = (s.f2[fp][fw] + a / (len(s.F) + 1)) / (s.nf[fp] + a)
        pw = (s.em[fw][w] + a * u) / (s.ne[fw] + a)
        return [u, b, t, pf * pw]
    def prob(s, w, pp, p, fp, mix=None):
        return sum(m * c for m, c in zip(mix or s.mix, s.comps(w, pp, p, fp)))
    # ── aprendizaje ──
    def ingest(s, sent):
        fs = [s.firma(w, sent[i-1] if i else None, sent[i+1] if i+1 < len(sent) else None, True) for i, w in enumerate(sent)]
        pp, p, fp = "<s>", "<s>", "<s>"; loss = 0.0
        for w, f in zip(sent, fs):
            c = s.comps(w, pp, p, fp); pm = sum(m * x for m, x in zip(s.mix, c)); loss -= math.log(pm)
            z = sum(m * x for m, x in zip(s.mix, c)); s.mix = [0.95 * (m * x / z) + 0.05 / 4 for m, x in zip(s.mix, c)]
            s.w1[w] += 1; s.w2[p][w] += 1; s.n2[p] += 1; s.w3[(pp, p)][w] += 1; s.n3[(pp, p)] += 1
            s.f2[fp][f] += 1; s.nf[fp] += 1; s.em[f][w] += 1; s.ne[f] += 1
            s.V.add(w); s.F.add(f); s.N += 1; pp, p, fp = p, w, f
        s.hist.append((s.N, loss / len(sent), list(s.mix)))
    def ppl(s, sents, mix=None):
        L = n = 0
        for sent in sents:
            pp, p, fp = "<s>", "<s>", "<s>"
            for w in sent:
                L -= math.log(s.prob(w, pp, p, fp, mix)); n += 1; pp, p, fp = p, w, s.cls(w)
        return math.exp(L / max(n, 1))
    # ── generación ──
    def gen(s, ctx, n=20, temp=0.8, k=15):
        t = tokenizar(ctx) if isinstance(ctx, str) else list(ctx); out = []
        for _ in range(n):
            pp, p = (["<s>", "<s>"] + t)[-2:]; fp = s.cls(p) if p != "<s>" else "<s>"
            c = sorted(((s.prob(w, pp, p, fp), w) for w in s.V), reverse=True)[:k]
            ws = [x ** (1 / temp) for x, _ in c]; w = random.choices([w for _, w in c], ws)[0]
            out.append(w); t.append(w)
            if w in ".?!…": break
        return " ".join(out)

def cargar_reglas(md):
    out = []
    for l in open(md, encoding="utf8"):
        m = RG.match(l)
        if m: out.append({"id": m[1], "prev": m[2], "next": m[3], "firma": m[4].replace(" ", " ")})
    return out
def nueva():
    lex = json.load(open(os.path.join(AQUI, "lexico_delta.json"), encoding="utf8"))
    return Semilla(lex, cargar_reglas(os.path.join(AQUI, "TEXTO_MADRE_DELTA_v5.md")))
def guardar(m): pickle.dump(m, open(ESTADO, "wb"))
def abrir(): return pickle.load(open(ESTADO, "rb")) if os.path.exists(ESTADO) else nueva()

def entrenar(archivos, holdout=10):
    m = nueva(); S = []
    for a in archivos: S += frases(open(a, encoding="utf8").read())
    ev = [x for i, x in enumerate(S) if i % holdout == 0]; tr = [x for i, x in enumerate(S) if i % holdout]
    for x in tr: m.ingest(x)
    w = m.mix; sin = [w[0], w[1], w[2], 0]; z = sum(sin); sin = [x / z for x in sin]
    print(f"entrenado: {m.N} tokens, {len(m.V)} palabras, {len(m.F)} clases, {len(m.apr)} palabras con firma aprendida, {len(m.pend)} sin firma")
    print(f"mezcla final [uni, bi, tri, clases] = {[round(x,2) for x in w]}")
    print(f"perplejidad held-out ({sum(map(len,ev))} tokens): mezcla completa {m.ppl(ev):.1f} | sin clases Δ {m.ppl(ev, sin):.1f} | solo clases {m.ppl(ev,[0,0,0,1]):.1f}")
    for i in range(0, len(m.hist), max(1, len(m.hist)//6)):
        n, l, mx = m.hist[i]; print(f"  tras {n:5d} tokens: pérdida en línea {l:.2f}  mezcla {[round(x,2) for x in mx]}")
    guardar(m); return m

if __name__ == "__main__":
    a = sys.argv[1:]
    if a[:1] == ["train"]: entrenar(a[1:])
    elif a[:1] == ["gen"]: print(abrir().gen(a[1], int(a[2]) if len(a) > 2 else 20))
    elif a[:1] == ["chat"]:
        m = abrir()
        while True:
            try: t = input("tú> ")
            except EOFError: break
            mm = re.match(r"^(\w+)\s*=\s*(Ξ\{[^}]*\})$", t.strip())
            if mm: m.lex[mm[1].lower()] = mm[2]; print("firma anclada"); guardar(m); continue
            for x in frases(t) or [tokenizar(t)]: m.ingest(x)
            print("Δ>", m.gen(t, 20))
            if m.pend: print("   sin firma:", ", ".join(w for w, _ in m.pend.most_common(3)), "(dime: palabra = Ξ{…})")
            guardar(m)
    else: print(__doc__)
