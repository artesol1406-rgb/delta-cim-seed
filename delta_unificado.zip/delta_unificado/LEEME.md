# Δ unificado

## Arranque (Termux)
    pkg update && pkg install python python-numpy
    cd delta_unificado
    python main.py            # terminal
    python servidor.py        # navegador en http://127.0.0.1:8000  (sin Flask)

La primera vez entrena la semilla con el Madre v5 (≈1 min en un PC; más en el teléfono) y guarda `semilla_R.pkl`. Después carga directo.

## Qué lee cada archivo
- `TEXTO_MADRE_DELTA_v5.md` es el texto de trabajo (v4 + tabla RITMO). El parser ya salta las líneas `RITMO |`: v4 y v5 dan las mismas 249 frases.
- `TEXTO_MADRE_DELTA_v4.md` solo lo lee `ritmo_corpus.py`, que LEE v4 y ESCRIBE v5. No lo ejecutes sobre v5 (añadiría una segunda tabla RITMO).
- `nucleo.py` une Semilla + CIM (Mente/Cuerpo) + HRR. `main.py` y `servidor.py` solo lo llaman.
- `memoria_hrr.py`: HRR real con `numpy.fft`, D=1024, dos niveles (palabra y estado sintáctico).

## Comandos de la terminal
`frase` · `▢` deja un hueco · `:tau 0.5` · `:crecer ruta.txt` · `:aprende frase` · `:estado` · `:hrr` · `:salir`

## Lo que no hace
- Con τ=0.90 la semilla casi nunca predice fuera del Madre (siempre hay demasiada superposición): la respuesta sale vacía. Baja τ para ver emisiones.
- La HRR acierta menos que la tabla exacta (fuera de muestra, top-1 4% frente a 11%): es una segunda opinión comprimida, no un mejor predictor.
