#!/usr/bin/env python3
"""SEMILLA Δ v3 — autónoma (solo necesita madre_patrones.py, semilla_delta.py, lexico_delta.json y el Madre v4).
Se mide por COMPETENCIAS, no por pérdida, y con validación anidada (la selección de rasgos NO ve el canto de prueba).

  RITMO      sección: modos 1→2→3→4→5.   canto: orden de respiración dado por Nik  P E P C P E P C P E P  (cada canto una fase).
             Ley de opuestos: tras una pausa, el siguiente polo es el OPUESTO del último polo activo (E ↔ C, con P entre ambos).
  POLARIDAD  fase de una frase (E expansión / P pausa / C contracción) por su FORMA, y por forma + estructura del párrafo.
  FLUJO      secciones generadas por el ritmo cancelan el balance (nº E = nº C).
  CRECER     frase sin etiqueta: su fase queda en superposición y las frases vecinas la colapsan (adelante-atrás).
PENDIENTE (manual): los polos de cada dimensión (p. ej. S dinámico / S estático) están en el manual, que no está entre los archivos.
Rellenar POLOS_MANUAL cuando se tenga; hoy solo se usa lo que el Madre y el HTML ya dicen.
Uso: python semilla_v3.py [TEXTO_MADRE_DELTA_v5.md]"""
import os, sys, re, json, math, random, collections as C
AQUI = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, AQUI)
import semilla_delta as SD

# ───────────── especificación (editable) ─────────────
FASES = "EPC"; VAL = {"E": 1, "P": 0, "C": -1}
# Modo del Madre → fase.  e1 extrovertido-ACTIVO = expansión; e2 extrovertido-ESTÁTICO = pausa; e3 introvertido-DINÁMICO = contracción;
# e4 introvertido-ESTÁTICO = pausa; geodésica = pausa (síntesis).  Derivado de las etiquetas del Madre y del HTML (estático/dinámico × activo/receptivo).
MODO_FASE = {1: "E", 2: "P", 3: "C", 4: "P", 5: "P"}
CANTO_FASE = dict(zip(range(1, 12), "PEPCPEPCPEP"))          # orden de respiración (Nik): pausa, expansión, pausa, contracción, …
POLOS_MANUAL = {}   # ← completar con el manual: {dimensión: (polo1, polo2)}, p. ej. "S": ("dinámico", "estático")
UMBRAL = {"ritmo": 0.90, "polaridad": 0.70, "flujo": 0.90, "crecer_precision": 0.80}   # propuestos, editables

TAB = re.compile(r"^\s*>?\s*(PALABRA|MORF|SINT|CONC|USO|ROSETTA|REGLA|RITMO)\b")
ETQ = re.compile(r"^\*\*(?:Modo\s+(\d)[^*]*|Voz[^(*]*\(e(\d)\)[^*]*|(Geod[^*]*))\*\*(.*)$")
LEX = None; PUNT = set(".,;:¿?¡!…")

# ───────────── datos ─────────────
def cargar(md):
    """Devuelve frases con (canto, sección, modo, fase, pos en el párrafo, nº de frases del párrafo) y las secuencias de modos."""
    global LEX; LEX = json.load(open(os.path.join(AQUI, "lexico_delta.json"), encoding="utf8"))
    canto = sec = 0; modo = None; recs = []; secs = {}
    for l in open(md, encoding="utf8"):
        if l.startswith("## CANTO"): canto += 1; sec += 1; modo = None; continue
        if l.startswith("### §"): sec += 1; modo = None; continue
        e = ETQ.match(l.strip()); txt = l
        if e:
            modo = int(e.group(1) or e.group(2) or 5); secs.setdefault(sec, []).append(modo); txt = e.group(4)
        elif modo is None or TAB.match(l) or l.startswith("#") or l.strip() in ("", "---"): continue
        if modo is None: continue
        txt = re.sub(r"^\*\*[^*]+\*\*\s*", "", txt.strip()).split("→")[0]
        ss = [t for t in SD.frases(txt) if len(t) >= 3]
        for i, t in enumerate(ss):
            recs.append(dict(t=t, canto=canto, sec=sec, modo=modo, fase=MODO_FASE[modo], pos=0 if i == 0 else (2 if i == len(ss) - 1 else 1), nfr=min(len(ss), 4)))
    return recs, [v for _, v in sorted(secs.items())]

def nw(t): return len([w for w in t if w not in PUNT])
def esverbo(w): return LEX.get(w, {}).get("cat") == "verbo"
FORMA = {"q": lambda r: "?" in r["t"],
         "len": lambda r: 0 if nw(r["t"]) <= 6 else (1 if nw(r["t"]) <= 14 else 2),
         "abre¿": lambda r: r["t"][0] == "¿",
         "coma": lambda r: min(2, r["t"].count(",")),
         "pers1": lambda r: bool({"yo", "tú", "usted"} & set(r["t"])),
         "verbo": lambda r: any(esverbo(w) for w in r["t"]),
         "excl": lambda r: "!" in r["t"]}
ESTRUCTURA = {"pos": lambda r: r["pos"], "nfr": lambda r: r["nfr"]}   # layout del párrafo: ¡ojo! es la misma estructura que define la etiqueta

# ───────────── clasificador por forma (naive Bayes, Laplace) ─────────────
class NB:
    def __init__(s, datos, fs):
        s.fs = fs; s.pri = C.Counter(r["fase"] for r in datos); s.n = len(datos); s.c = {f: {n: C.Counter() for n in fs} for f in FASES}; s.v = {n: set() for n in fs}
        for r in datos:
            for n in fs: x = ALL[n](r); s.c[r["fase"]][n][x] += 1; s.v[n].add(x)
    def lik(s, r):
        out = {}
        for f in FASES:
            l = 1.0
            for n in s.fs: l *= (s.c[f][n][ALL[n](r)] + 1) / (s.pri[f] + len(s.v[n]) + 1)
            out[f] = l
        return out
    def post(s, r):
        L = s.lik(r); p = {f: L[f] * (s.pri[f] + 1) / (s.n + 3) for f in FASES}; z = sum(p.values()); return {f: v / z for f, v in p.items()}
ALL = FORMA | ESTRUCTURA

def por_canto(recs):
    d = C.defaultdict(list)
    for r in recs: d[r["canto"]].append(r)
    return d

def cv_acc(cantos, fs):
    """Dejar fuera UN canto."""
    ok = n = 0
    for k in cantos:
        tr = [r for c, v in cantos.items() if c != k for r in v]; m = NB(tr, fs)
        for r in cantos[k]: n += 1; p = m.post(r); ok += max(p, key=p.get) == r["fase"]
    return ok / n

def seleccionar(cantos, cand, margen=0.005):
    """Selección hacia delante de rasgos, evaluada SOLO con los cantos de entrenamiento (validación interna)."""
    cur = []; best = cv_acc(cantos, cur)
    while True:
        res = {f: cv_acc(cantos, cur + [f]) for f in cand if f not in cur}
        if not res: break
        f = max(res, key=res.get)
        if res[f] > best + margen: cur.append(f); best = res[f]
        else: break
    return cur

def polaridad_anidada(recs, cand):
    """Validación ANIDADA: el canto de prueba no interviene en elegir los rasgos."""
    cantos = por_canto(recs); ok = n = 0; elegidos = {}
    for k in cantos:
        tr = {c: v for c, v in cantos.items() if c != k}; fs = seleccionar(tr, cand); elegidos[k] = fs
        m = NB([r for v in tr.values() for r in v], fs)
        for r in cantos[k]: n += 1; p = m.post(r); ok += max(p, key=p.get) == r["fase"]
    return ok / n, n, elegidos

def polaridad_sesgada(recs, cand):
    """Lo que hacía la prueba anterior: probar todos los rasgos sobre los mismos cantos y quedarse con el mejor (optimista)."""
    cantos = por_canto(recs); return max(cv_acc(cantos, [f]) for f in cand), cv_acc(cantos, list(cand))

# ───────────── ritmo ─────────────
class Ritmo:
    """P(siguiente | contexto).  orden=1: contexto = fase actual.  orden=2: contexto = (último polo activo, fase actual)."""
    def __init__(s, seqs, estados, orden=1, alpha=0.3):
        s.o, s.al, s.E = orden, alpha, list(estados) + ["$"]; s.T = C.defaultdict(C.Counter)
        for q in seqs:
            for i, b in enumerate(list(q[1:]) + ["$"]): s.T[s.ctx(q, i)][b] += 1
    def ctx(s, q, i):
        if s.o == 1: return q[i]
        ult = next((x for x in reversed(q[:i + 1]) if x in "EC"), "-"); return (ult, q[i])
    def p(s, c, b): return (s.T[c][b] + s.al) / (sum(s.T[c].values()) + s.al * len(s.E))
    def mejor(s, c): return max(s.E, key=lambda b: s.T[c][b])

def ritmo_secciones(secs):
    ok = n = 0
    for k, s in enumerate(secs):
        m = Ritmo([q for i, q in enumerate(secs) if i != k], [1, 2, 3, 4, 5])
        for i in range(len(s) - 1): n += 1; ok += m.mejor(s[i]) == s[i + 1]
    return ok / n, n

def ritmo_cantos():
    """El orden de Nik es una ESPECIFICACIÓN.  Pregunta útil: ¿alcanza un modelo de orden 1 o hace falta el último polo (orden 2)?"""
    q = [CANTO_FASE[c] for c in range(1, 12)]; res = {}
    for o in (1, 2):
        m = Ritmo([q], "EPC", o); res[o] = sum(m.mejor(m.ctx(q, i)) == q[i + 1] for i in range(len(q) - 1)) / (len(q) - 1)
    alt = [x for x in q if x != "P"]; opuestos = all(a != b for a, b in zip(alt, alt[1:]))
    return res, opuestos, "".join(q)

def elegir_alpha(secs, grilla=(1.0, 0.3, 0.1, 0.03)):
    """Suavizado por log-pérdida dejando fuera una sección (no a mano para que pase una prueba)."""
    def L(al):
        t = 0.0
        for k, q in enumerate(secs):
            m = Ritmo([x for i, x in enumerate(secs) if i != k], [1, 2, 3, 4, 5], 1, al); t -= sum(math.log(m.p(m.ctx(q, i), b)) for i, b in enumerate(list(q[1:]) + ["$"]))
        return t
    return min(grilla, key=L)

def flujo(secs, rng, N=2000):
    """Secciones generadas desde el ritmo de modos aprendido; el balance (E=+1, C=−1) debe terminar cancelado."""
    al = elegir_alpha(secs); m = Ritmo(secs, [1, 2, 3, 4, 5], 1, al); bien = 0
    for _ in range(N):
        s = [1]                                   # toda sección empieza en el modo 1 (expansión)
        while len(s) < 8:
            b = rng.choices(m.E, [m.p(s[-1], x) for x in m.E])[0]
            if b == "$": break
            s.append(b)
        bien += sum(VAL[MODO_FASE[x]] for x in s) == 0
    return bien / N, al

# ───────────── crecer: superposición de la fase de una frase y colapso retroactivo ─────────────
def hmm(nb, rm, frases):
    n = len(frases); em = [nb.lik(r) for r in frases]; a = []; b = [None] * n
    for i in range(n):
        v = {f: em[i][f] * ((nb.pri[f] + 1) if i == 0 else sum(a[-1][g] * rm.p(g, f) for g in FASES)) for f in FASES}; z = sum(v.values()); a.append({f: x / z for f, x in v.items()})
    b[-1] = {f: 1.0 for f in FASES}
    for i in range(n - 2, -1, -1):
        v = {f: sum(rm.p(f, g) * em[i + 1][g] * b[i + 1][g] for g in FASES) for f in FASES}; z = sum(v.values()); b[i] = {f: x / z for f, x in v.items()}
    out = []
    for i in range(n):
        v = {f: a[i][f] * b[i][f] for f in FASES}; z = sum(v.values()); out.append({f: x / z for f, x in v.items()})
    return out

def crecer(recs, cand, taus=(0.6, 0.7, 0.8, 0.9)):
    cantos = por_canto(recs); tot = ok_h = ok_e = 0; cur = {t: [0, 0] for t in taus}
    for k in cantos:
        tr = {c: v for c, v in cantos.items() if c != k}; fs = seleccionar(tr, cand); nb = NB([r for v in tr.values() for r in v], fs)
        rm = Ritmo([[r["fase"] for r in v] for v in tr.values()], FASES, 1); post = hmm(nb, rm, cantos[k])
        for r, p in zip(cantos[k], post):
            tot += 1; g = max(p, key=p.get); ok_h += g == r["fase"]; pe = nb.post(r); ok_e += max(pe, key=pe.get) == r["fase"]
            for t in taus:
                if p[g] >= t: cur[t][0] += 1; cur[t][1] += g == r["fase"]
    return tot, ok_e / tot, ok_h / tot, {t: (c / tot, a / c if c else 0) for t, (c, a) in cur.items()}

def main(md):
    rng = random.Random(0); recs, secs = cargar(md); cantos = por_canto(recs)
    mj = C.Counter(r["fase"] for r in recs); may = max(mj.values()) / len(recs)
    print(f"Madre: {len(recs)} frases con fase en {len(cantos)} cantos {sorted(cantos)}; {len(secs)} secciones con modos ({sum(len(s)-1 for s in secs)} transiciones); fases {dict(mj)}; mayoritaria {may:.0%}")
    log = []
    r, n = ritmo_secciones(secs); print(f"RITMO sección  siguiente modo, dejando fuera una sección: {r:.0%} ({n} transiciones)  [azar 20 %]"); log.append(("ritmo", r))
    res, opp, q = ritmo_cantos()
    print(f"RITMO canto    orden dado {q}: orden 1 predice {res[1]:.0%}, orden 2 (último polo + pausa) {res[2]:.0%}; polos activos alternan E↔C: {'sí' if opp else 'no'}")
    print("               (es una especificación, no una medición: confirma que el orden E P C P necesita 2.º orden y que respeta la ley de opuestos)")
    fl, al = flujo(secs, rng); print(f"FLUJO          secciones generadas con balance cancelado (E = C): {fl:.0%}  (suavizado α={al} elegido por validación)"); log.append(("flujo", fl))
    print("\nPOLARIDAD por forma, validación ANIDADA (el canto de prueba no elige los rasgos):")
    for nombre, cand in (("forma de la frase", list(FORMA)), ("forma + estructura del párrafo", list(FORMA) + list(ESTRUCTURA))):
        a, nn, el = polaridad_anidada(recs, cand); b1, ball = polaridad_sesgada(recs, cand)
        freq = C.Counter(f for v in el.values() for f in v).most_common(4)
        print(f"  {nombre:32s} anidada {a:.0%} ({nn} frases)   [mayoritaria {may:.0%}]   protocolo sesgado anterior: mejor rasgo suelto {b1:.0%}, todos {ball:.0%}   rasgos más elegidos {freq}")
        log.append((f"polaridad: {nombre}", a))
    print("\nCRECER  fase de frases sin etiqueta: superposición abierta hacia delante, colapsada hacia atrás por las vecinas (validación anidada)")
    for nombre, cand in (("solo forma", list(FORMA)), ("forma + estructura", list(FORMA) + list(ESTRUCTURA))):
        tot, ae, ah, cur = crecer(recs, cand); print(f"  [{nombre}] {tot} frases: sin vecinas {ae:.0%} → con ritmo y colapso retroactivo {ah:.0%}")
        for t, (c, p) in cur.items(): print(f"     τ={t}: fija {c:.0%} de las frases con precisión {p:.0%}; el resto queda en superposición")
    print("\nCOMPETENCIAS (umbrales propuestos, editables):")
    for k, v in log:
        u = UMBRAL.get(k.split(":")[0], UMBRAL["polaridad"]); print(f"  {'PASA   ' if v >= u else 'NO PASA'} {k}: {v:.0%} (umbral {u:.0%})")
    print("\nPendiente: " + ("polos del manual sin cargar (POLOS_MANUAL vacío)." if not POLOS_MANUAL else "ninguno."))
    json.dump({"competencias": log, "crecer": [tot, ae, ah]}, open(os.path.join(AQUI, "semilla_v3_resultados.json"), "w"), indent=1)

if __name__ == "__main__":
    main(next((a for a in sys.argv[1:] if not a.startswith("--")), os.path.join(AQUI, "TEXTO_MADRE_DELTA_v5.md")))
