#!/usr/bin/env python3
"""CIM v1 — las dos mentes aplicadas a la semilla.

  MENTE  (activa-estática)    influye sin moverse: estructura que condiciona (cuentas del Madre, prior gramatical, clases comprometidas).
                              Durante la inferencia es SOLO LECTURA; solo cambia al consolidar (contracción del contenedor).
  CUERPO (receptiva-dinámica) se mueve al recibir: mantiene abiertas las superposiciones (huecos) y las colapsa hacia atrás cuando llega lo siguiente.

Política de decisión por posición (de la más a la menos segura):
  PREDICE        la palabra más probable tiene P ≥ τ_palabra (por defecto 0.90: «muy cerca de la certeza»)
  PREDICE CLASE  la palabra queda abierta, pero el estado sintáctico (categoría, género, número) tiene P ≥ τ_clase
  ABRE           pocas superposiciones (n_efectivo ≤ K): no predice; las sostiene abiertas hasta que llegue lo siguiente
  RETRO          demasiadas superposiciones (n_efectivo > K): no las sostiene; piensa hacia atrás con el contexto derecho
n_efectivo = exp(entropía) de la distribución sobre las palabras, con la cola no vista repartida en el resto del vocabulario.

POLARIDAD RELATIVA (analizador v12): p(x | ancla) = +1 si x sostiene al ancla, −1 si la confronta.  Se calcula sobre un grafo de signos:
p = producto de signos por el camino; lo invariante es la topología (las aristas) y los campos; lo relativo, qué campo es «+» según el ancla.
La TENSIÓN es la fracción de aristas frustradas (ciclos que no cierran en equilibrio).  Semántica de los signos tomada del Madre
(Canto II/III): con, y, e = +1 (sostienen) · sin, contra, pero, sino = −1 (confrontan).
Uso: python cim.py   (necesita entrenar_semilla.py, crecer.py y los módulos del Madre)"""
import os, sys, math, random, collections as C
AQUI = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, AQUI)
import entrenar_semilla as E, crecer as K

TAU_PALABRA = 0.90; TAU_CLASE = 0.90; K_MAX = 20; SIGNO = {"con": 1, "y": 1, "e": 1, "sin": -1, "contra": -1, "pero": -1, "sino": -1}

# ───────────── Mente (solo lectura) y Cuerpo (superposiciones abiertas) ─────────────
class Mente:
    """Activa-estática: condiciona sin moverse.  Envuelve semilla y cuentas; no expone escritura durante la inferencia."""
    def __init__(s, S, cnt, pesos=None): s.S, s.cnt, s.pesos = S, cnt, pesos
    def lee(s, t, i, rng):
        S = s.S; viejo = S.m
        if s.pesos: S.m = s.pesos
        try:
            ctxs = S.contextos(t); ctx = ctxs[i]; props = S.propuestas(s.cnt, ctx, rng); props.add(t[i])
            P = {x: S.prob(s.cnt, x, ctx) for x in props}; cola = max(1e-9, 1 - sum(P.values())); tot = sum(P.values()) + cola
            nrest = max(1, len(s.cnt.V) - len(props))
            H = -sum((v / tot) * math.log(v / tot) for v in P.values() if v > 0) + (cola / tot) * (math.log(nrest) - math.log(cola / tot))
            top = sorted(P, key=P.get, reverse=True); dS = S.dS(s.cnt, ctx[3]); st = max(dS, key=dS.get)
            lec = dict(P=P, tot=tot, neff=math.exp(H), top=top, pw=P[top[0]] / tot, st=st, pst=dS[st], st_ok=(st == S.estado(t[i])))
            if i + 1 < len(t):
                r = t[i + 1]; num = {x: P[x] * S.prob(s.cnt, r, S.sig(x, ctx)) for x in props}; lec["retro"] = sorted(num, key=num.get, reverse=True)
            return lec
        finally: S.m = viejo

class Cuerpo:
    """Receptiva-dinámica: sostiene huecos abiertos y los colapsa hacia atrás."""
    def __init__(s): s.huecos = []
    def abre(s, i): s.huecos.append(i)
    def colapsa(s, lec): return lec.get("retro")

def decidir(lec, tau_w=TAU_PALABRA, tau_c=TAU_CLASE, kmax=K_MAX):
    if lec["pw"] >= tau_w: return "predice"
    if lec["pst"] >= tau_c: return "predice_clase"
    return "retro" if lec["neff"] > kmax else "abre"

def evaluar_politica(mente, sents, rng, filtro=None, tau_w=TAU_PALABRA, tau_c=TAU_CLASE, kmax=K_MAX):
    """Recorre las frases; devuelve estadísticas por acción."""
    R = C.defaultdict(lambda: C.defaultdict(list)); n = 0
    for k, (cn, t, peso, _) in enumerate(sents):
        if filtro and not filtro(k) or len(t) < 2: continue
        for i in range(len(t)):
            lec = mente.lee(t, i, rng); a = decidir(lec, tau_w, tau_c, kmax); n += 1; w = t[i]; R[a]["n"].append(1)
            R[a]["f1"].append(lec["top"][0] == w); R[a]["f5"].append(w in lec["top"][:5]); R[a]["st"].append(lec["st_ok"])
            if "retro" in lec: R[a]["r1"].append(lec["retro"][0] == w); R[a]["r5"].append(w in lec["retro"][:5]); R[a]["f1r"].append(lec["top"][0] == w); R[a]["f5r"].append(w in lec["top"][:5])
    return R, n

def resumen(R, n, nombre, log=print):
    m = lambda v: (sum(v) / len(v)) if v else float("nan")
    log(f"  [{nombre}] {n} posiciones")
    for a in ("predice", "predice_clase", "abre", "retro"):
        d = R.get(a)
        if not d: log(f"     {a:14s}   0%"); continue
        c = len(d["n"]); linea = f"     {a:14s} {c/n:4.0%}  "
        if a == "predice": linea += f"acierta {m(d['f1']):.0%} de las veces que se atreve"
        elif a == "predice_clase": linea += f"clase correcta {m(d['st']):.0%}; la palabra queda abierta"
        elif a == "abre": linea += f"no predice; sus {5} mejores candidatas contienen la palabra {m(d['f5']):.0%}"
        else: linea += f"adelante top1 {m(d['f1r']):.0%} top5 {m(d['f5r']):.0%} → con contexto derecho top1 {m(d['r1']):.0%} top5 {m(d['r5']):.0%}"
        log(linea)

# ───────────── polaridad relativa: grafo de signos ─────────────
def polaridad_relativa(aristas, ancla):
    """aristas: [(a, b, signo)], signo ±1.  Devuelve (p, tension): p[x] = signo del camino ancla→x; tension = fracción de aristas frustradas."""
    ady = C.defaultdict(list)
    for a, b, s in aristas: ady[a].append((b, s)); ady[b].append((a, s))
    p = {ancla: 1}; cola = [ancla]
    while cola:
        u = cola.pop(0)
        for v, s in ady[u]:
            if v not in p: p[v] = p[u] * s; cola.append(v)
    frust = sum(1 for a, b, s in aristas if a in p and b in p and p[a] * p[b] != s)
    return p, frust / max(1, len(aristas))

def comparar_anclas(aristas, anclas):
    """Como el analizador: topología invariante (mismos nodos) y fracción de polos que se invierten entre anclas."""
    runs = {a: polaridad_relativa(aristas, a) for a in anclas}; out = []
    for i, a in enumerate(anclas):
        for b in anclas[i + 1:]:
            comunes = [x for x in runs[a][0] if x in runs[b][0] and x not in (a, b)]
            out.append((a, b, sum(runs[a][0][x] != runs[b][0][x] for x in comunes) / max(1, len(comunes)), runs[a][1]))
    return out

def prueba_polaridad(log=print):
    log("\nPOLARIDAD RELATIVA (grafo de signos, prueba sintética con tres partes):")
    eq = [("A", "B", 1), ("B", "C", -1), ("A", "C", -1)]             # equilibrado: B sostiene a A y confronta a C
    for nombre, ar in (("equilibrado", eq), ("frustrado", [("A", "B", -1), ("B", "C", -1), ("A", "C", -1)])):
        for a, b, inv, tens in comparar_anclas(ar, ["A", "C"]):
            log(f"  {nombre:12s} ancla {a} frente a ancla {b}: polos invertidos en los demás {inv:.0%}; tensión (aristas frustradas) {tens:.0%}")
        p, _ = polaridad_relativa(ar, "A"); q, _ = polaridad_relativa(ar, "C"); log(f"     B visto desde A: {p['B']:+d}   B visto desde C: {q['B']:+d}")

def aristas_del_texto(t):
    """Primera operacionalización (burda): conectores con signo entre el término anterior y el siguiente."""
    ar = []
    for i, w in enumerate(t):
        if w in SIGNO and 0 < i < len(t) - 1 and t[i - 1] not in E.PUNT and t[i + 1] not in E.PUNT: ar.append((t[i - 1], t[i + 1], SIGNO[w]))
    return ar

def main():
    md = os.path.join(AQUI, "TEXTO_MADRE_DELTA_v5.md"); log = print
    log("entrenando la semilla con el Madre completo…"); S, M, _ = E.entrenar(md, log=lambda *a: None); rng = random.Random(0)
    log(f"\nPOLÍTICA: predice si P ≥ {TAU_PALABRA}; si no, predice la clase si P ≥ {TAU_CLASE}; si no, abre (n_efectivo ≤ {K_MAX}) o piensa hacia atrás (n_efectivo > {K_MAX})")
    cnt = S.construir(M.frases); R, n = evaluar_politica(Mente(S, cnt, S.mm), M.frases, rng); resumen(R, n, "Madre, dentro de muestra (maestría)")
    R2 = C.defaultdict(lambda: C.defaultdict(list)); n2 = 0
    for k in range(E.K_PLIEGUES):
        r, nn = evaluar_politica(Mente(S, S.construir(M.frases, excluir=k), S.m), M.frases, rng, filtro=lambda i, k=k: i % E.K_PLIEGUES == k)
        n2 += nn
        for a, d in r.items():
            for key, v in d.items(): R2[a][key] += v
    resumen(R2, n2, "Madre, fuera de muestra (5 pliegues)")
    log("\nCOBERTURA frente a PRECISIÓN de la predicción de palabra (umbral τ):")
    for tau in (0.5, 0.7, 0.9, 0.95):
        r, nn = evaluar_politica(Mente(S, cnt, S.mm), M.frases, rng, tau_w=tau); d = r.get("predice")
        r3, nn3 = evaluar_politica(Mente(S, S.construir(M.frases, excluir=0), S.m), M.frases, rng, filtro=lambda i: i % E.K_PLIEGUES == 0, tau_w=tau); d3 = r3.get("predice")
        f = lambda d, n: f"cubre {len(d['n'])/n:4.0%} acierta {sum(d['f1'])/len(d['f1']):.0%}" if d else "no se atreve nunca"
        log(f"  τ={tau}: dentro de muestra {f(d, nn)}  |  fuera de muestra (pliegue 0) {f(d3, nn3)}")
    ruta = os.path.join(AQUI, "textos", "vacio_texto_propio.txt")
    if os.path.exists(ruta):
        log("\nCRECIMIENTO con tu texto (tandas de 4 frases; antes de aprender cada tanda):")
        T = K.tandas(ruta, 4); import copy; Sc = copy.deepcopy(S); base = list(M.frases)
        for i, tr in enumerate(T):
            r, nn = evaluar_politica(Mente(Sc, Sc.construir(base), Sc.m), tr, rng)
            c = {a: len(r[a]["n"]) / nn if a in r else 0 for a in ("predice", "predice_clase", "abre", "retro")}
            log(f"  tanda {i+1}: predice {c['predice']:.0%} · predice clase {c['predice_clase']:.0%} · abre {c['abre']:.0%} · retro {c['retro']:.0%}")
            base = K.absorber(Sc, base, tr)
    prueba_polaridad(log)
    log("\nGrafo de signos sobre el Madre (conectores con, y, e, sin, contra, pero, sino entre términos vecinos):")
    ar = [x for _, t, _, _ in M.frases for x in aristas_del_texto(t)]; log(f"  {len(ar)} aristas, +{sum(1 for *_, s in ar if s > 0)} / −{sum(1 for *_, s in ar if s < 0)}; es una primera operacionalización: faltan los portadores reales de cada relación")

if __name__ == "__main__": main()
