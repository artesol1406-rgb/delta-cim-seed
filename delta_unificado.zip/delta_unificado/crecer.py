#!/usr/bin/env python3
"""crecer.py — bucle de crecimiento de la semilla Δ.  La semilla (Madre) queda abierta: cada TANDA de texto nuevo entra por el ciclo
   EXPANDE (el contenedor recibe y se mide la sorpresa, fuera de muestra: «prequential»)  →  CONTRAE (colapso retroactivo de las clases
   de palabras nuevas y se guarda)  →  METAESTABILIDAD (se comprueba que el Madre no se degrada y que la semilla no se cierra).
Tres números por tanda y uno final:
  PLASTICIDAD  sorpresa (nats/token) de la tanda nueva ANTES de aprenderla; debe bajar si lo absorbido ayuda con lo siguiente.
  CONTROL      igual, pero absorbiendo las mismas tandas con las palabras barajadas dentro de cada frase (mismo vocabulario, sin sintaxis).
               Si el real no gana al barajado, lo aprendido es vocabulario, no estructura.  También se mide la semilla sola (sin crecer).
  APERTURA     varianza (entropía normalizada) de la superposición sobre lo nuevo: si cae a ~0 la semilla se cerró (exceso de seguridad).
  ESTABILIDAD  (final) el Madre sigue sabido: maestría (pérdida retroactiva dentro del Madre) y pares mínimos (concordancia, orden, uso).
Uso: python crecer.py texto1.txt [texto2.txt …] [--tanda=4]      (un archivo = un contexto; el nombre del archivo es la etiqueta de contexto)
Requiere: entrenar_semilla.py, entrenar_cim.py y los módulos del Madre en la misma carpeta."""
import os, sys, random, copy, collections as C
AQUI = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, AQUI)
import entrenar_semilla as E, semilla_delta as SD
from entrenar_cim import medir

def tandas(ruta, n):
    t = " ".join(open(ruta, encoding="utf8").read().split()); fr = [x for x in SD.frases(t) if len(x) >= 3]
    return [[(99, x, 1, "extra") for x in fr[i:i + n]] for i in range(0, len(fr), n)]

def barajar(tanda, rng):
    out = []
    for c, t, p, o in tanda:
        cuerpo, fin = t[:-1], t[-1:]; cuerpo = cuerpo[:]; rng.shuffle(cuerpo); out.append((c, cuerpo + fin, p, o))
    return out

def absorber(S, base, tanda):
    """CONTRAE: las palabras nuevas entran con clase latente y se colapsan con sus vecinos (retroactivo); se guarda."""
    nuevo = base + tanda
    for _, t, _, _ in tanda:
        for w in t:
            if S.M.info(w)[2] is None and w not in S.LAT: S.LAT[w] = "?"
    E.colapsar_latentes(S, nuevo); S.m = E.ajustar_pesos(S, nuevo, S.m, insample=False, iters=3); return nuevo

def prequential(S0, M, reales, controles=None, semilla=0):
    """Para cada tanda real: medir ANTES de aprender y luego absorber `controles[i]` (o la propia tanda real)."""
    S = copy.deepcopy(S0); rng = random.Random(semilla); base = list(M.frases); filas = []
    for i, tr in enumerate(reales):
        cnt = S.construir(base); s = medir(S, cnt, tr, rng); V = cnt.V
        toks = [w for _, t, _, _ in tr for w in t if w not in E.PUNT]; s["oov"] = sum(w not in V for w in toks) / len(toks); filas.append(s)
        base = absorber(S, base, (controles[i] if controles else tr))
    return S, base, filas

def retencion(S, M, extra, rng):
    cnt = S.construir(M.frases + extra); mi = medir(S, cnt, M.frases, rng, pesos=S.mm)
    idx = {}; res = {}; cache = {}
    for i, (_, t, _, _) in enumerate(M.frases): idx.setdefault(tuple(t), i)
    for tipo, pares in M.pares.items():
        ok = 0
        for a, b in pares:
            k = idx.get(tuple(a), 0) % E.K_PLIEGUES
            if k not in cache: cache[k] = S.construir(M.frases + extra, excluir=k)
            ok += E.puntuar(S, cache[k], a) > E.puntuar(S, cache[k], b)
        res[tipo] = (ok, len(pares))
    return mi, res

def main(rutas, n):
    log = print; md = os.path.join(AQUI, "TEXTO_MADRE_DELTA_v5.md")
    log("entrenando la semilla con el Madre completo…"); S0, M, _ = E.entrenar(md, log=lambda *a: None)
    rng = random.Random(0); mi0, par0 = retencion(S0, M, [], rng)
    log(f"semilla: maestría retro {mi0['lr']:.3f} | pares " + " ".join(f"{k} {a}/{b}" for k, (a, b) in par0.items()))
    for ruta in rutas:
        ctx = os.path.splitext(os.path.basename(ruta))[0]; T = tandas(ruta, n); toks = sum(len(t) for tr in T for _, t, _, _ in tr)
        cob = sum(1 for tr in T for _, t, _, _ in tr for w in t if w not in E.PUNT and M.info(w)[2] is not None) / max(1, sum(1 for tr in T for _, t, _, _ in tr for w in t if w not in E.PUNT))
        log(f"\n── contexto «{ctx}»: {len(T)} tandas de {n} frases, {toks} tokens; palabras con firma Δ conocida: {cob:.0%} ──")
        r2 = random.Random(1); ctrl = [barajar(tr, r2) for tr in T]
        Sr, base, fr = prequential(S0, M, T)                                   # real
        _, _, fb = prequential(S0, M, T, ctrl)                                 # control: barajado
        # semilla sola, sin crecer
        cnt0 = S0.construir(M.frases); solo = [medir(S0, cnt0, tr, random.Random(0)) for tr in T]
        log(f"{'tanda':>5} {'OOV':>5} | sorpresa: semilla sola | creciendo (real) | creciendo (barajado) | varianza apertura (real)")
        for i in range(len(T)):
            log(f"{i+1:>5} {fr[i]['oov']:>4.0%} | {solo[i]['lf']:>20.2f} | {fr[i]['lf']:>16.2f} | {fb[i]['lf']:>20.2f} | {fr[i]['hpre']:.2f}→{fr[i].get('hpost', float('nan')):.2f}")
        m = lambda L, k, a=1: sum(x[k] for x in L[a:]) / len(L[a:])
        log(f"media tandas 2..{len(T)}:  semilla sola {m(solo,'lf'):.2f}  |  real {m(fr,'lf'):.2f}  |  barajado {m(fb,'lf'):.2f}   (menor = menos sorpresa)")
        log(f"apertura (varianza pre-colapso, media): real {m(fr,'hpre',0):.2f}  [semilla sola {m(solo,'hpre',0):.2f}]")
        mi, par = retencion(Sr, M, base[len(M.frases):], rng)
        log(f"ESTABILIDAD tras crecer: maestría retro {mi0['lr']:.3f} → {mi['lr']:.3f} | pares " + " ".join(f"{k} {par0[k][0]}→{a}/{b}" for k, (a, b) in par.items()))

if __name__ == "__main__":
    a = [x for x in sys.argv[1:] if not x.startswith("--")]; n = next((int(x.split("=")[1]) for x in sys.argv if x.startswith("--tanda=")), 4)
    main(a or [os.path.join(AQUI, "textos", "vacio_texto_propio.txt")], n)
