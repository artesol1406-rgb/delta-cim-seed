#!/usr/bin/env python3
"""python servidor.py [puerto]  → http://127.0.0.1:8000   Solo biblioteca estándar + numpy (sin Flask).  El HTML solo muestra; toda la física está en Python.
  GET  /                 interfaz.html          GET  /api/estado
  POST /api/procesar     {"texto": "...", "tau": 0.9}  →  {"tokens": [...], "respuesta": {...}}
  POST /api/crecer       {"texto": "..."}              →  {"frases": n, "vocabulario": v}"""
import os, sys, json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from nucleo import Delta, AQUI
D = Delta(); BLOQUEO = __import__("threading").Lock()
class H(BaseHTTPRequestHandler):
    def _json(s, obj, code=200):
        b = json.dumps(obj, ensure_ascii=False).encode("utf8"); s.send_response(code); s.send_header("Content-Type", "application/json; charset=utf-8")
        s.send_header("Content-Length", str(len(b))); s.end_headers(); s.wfile.write(b)
    def do_GET(s):
        if s.path == "/api/estado": return s._json(D.estado())
        if s.path in ("/", "/index.html"):
            b = open(os.path.join(AQUI, "interfaz.html"), "rb").read(); s.send_response(200); s.send_header("Content-Type", "text/html; charset=utf-8")
            s.send_header("Content-Length", str(len(b))); s.end_headers(); return s.wfile.write(b)
        s._json({"error": "no existe"}, 404)
    def do_POST(s):
        try: cuerpo = json.loads(s.rfile.read(int(s.headers.get("Content-Length", 0))) or b"{}")
        except ValueError: return s._json({"error": "JSON inválido"}, 400)
        texto = str(cuerpo.get("texto", ""))[:5000]
        with BLOQUEO:
            if s.path == "/api/procesar": return s._json(D.procesar(texto, cuerpo.get("tau")))
            if s.path == "/api/crecer": return s._json(D.crecer(texto))
        s._json({"error": "no existe"}, 404)
    def log_message(s, *a): pass
if __name__ == "__main__":
    puerto = int(sys.argv[1]) if len(sys.argv) > 1 else 8000
    print(f"Δ en http://127.0.0.1:{puerto}"); ThreadingHTTPServer(("127.0.0.1", puerto), H).serve_forever()
