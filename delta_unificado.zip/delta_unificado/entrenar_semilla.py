#!/usr/bin/env python3
"""Entrenamiento de la SEMILLA Δ sobre el Códice Madre completo.

No genera texto: minimiza pérdida y varianza con el método de COLAPSO RETROACTIVO.
  · La palabra siguiente colapsa la superposición de la anterior:  P(w | izq, der) ∝ P(w | izq) · P(der | izq, w)
  · Las clases latentes (palabras sin firma) se colapsan con el mismo mecanismo (EM duro):  P(c | cp, cr) ∝ P(c | cp) · P(cr | c)
  · ATRACTOR de flujo de oración (respiración): estado x = (exhalación e, inhalación i) con fuga λ; el atractor cancela el
    desbalance b = e − i  (cancelación activa de APR v2: c = −P n).  Su peso κ se APRENDE; si no ayuda, κ → 0.
  · REGLAS sintácticas/gramaticales como PRIOR (pseudo-cuentas de Dirichlet): patrones SINT, concordancia CONC (género/número).
  · Currículo por cantos (1..11, acumulativo), validación cruzada de 5 pliegues (pérdida fuera de muestra, no memorización).
Métricas: pérdida hacia delante, pérdida retroactiva, varianza de la superposición de clases (entropía normalizada) antes y
después del colapso, y aciertos top-1/top-5.
Uso: python entrenar_semilla.py [TEXTO_MADRE_DELTA_v5.md] [--rapido]
Solo biblioteca estándar + madre_patrones.py + semilla_delta.py."""
import re, os, sys, math, random, pickle, time, collections as C
AQUI = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, AQUI)
import madre_patrones as MP, semilla_delta as SD

PUNT = set(".,;:¿?¡!…"); OUT = {"φe", "E", "A"}; IN = {"φc", "M", "F"}
TAB = re.compile(r"^\s*>?\s*(PALABRA|MORF|SINT|CONC|USO|ROSETTA|REGLA|RITMO)\b")
K_PLIEGUES = 5; LAM = 0.8
ETQ = re.compile(r"^\*\*(?:Modo\s+(\d)[^*]*|Voz[^(*]*\(e(\d)\)[^*]*|(Geod[^*]*))\*\*(.*)$")   # modo e1..e4, geodésica=5

def simbolos(f): return re.sub(r"[Ξ{}]", " ", f).split() if f else []
def pol(f): s = simbolos(f); return sum(x in OUT for x in s) - sum(x in IN for x in s)
def toks(t): return [x.lower() for x in SD.TOK.findall(t)]
def cerrar(t): return t if t and t[-1] in ".?!…" else t + ["."]
def H(p):
    n = len(p)
    return 0.0 if n < 2 else -sum(v * math.log(v) for v in p if v > 0) / math.log(n)

# ───────────────────────── datos: el Madre como DATOS ─────────────────────────
class Madre:
    def __init__(s, md):
        s.d = MP.leer(md); s.lex, s.lemas = MP.construir_lexico(s.d); s.gen = MP.generar_formas(s.lex, s.lemas, s.d["MORF"])
        s.patrones = [(f[0], f[1].split()) for f in s.d["SINT"]]
        s.frases = []                       # (canto, tokens, peso, origen)
        s.pares = {"CONC": [], "USO": [], "SINT": []}   # (ok, mal) para pruebas de par mínimo
        canto = 0; s._sec = 0; s._modo = 0; s.meta = []          # meta[i] = (sección, modo) de frases[i]; modo 0 = sin modo
        for l in open(md, encoding="utf8"):
            if l.startswith("## CANTO"): canto += 1; s._sec += 1; s._modo = 0; continue
            if l.startswith("### §"): s._sec += 1; s._modo = 0; continue
            e_ = ETQ.match(l.strip())
            if e_: s._modo = int(e_.group(1) or e_.group(2) or 5)
            m = TAB.match(l)
            if m:
                p = [x.strip() for x in l.rstrip("\n").split("|")]; k = m.group(1)
                ej = lambda c: [cerrar(toks(x.lstrip("* "))) for x in c.split(";") if x.strip()]
                if k == "SINT" and len(p) >= 5:
                    for e in ej(p[4]): s._add(canto, e, 3, "oro"); s.pares["SINT"].append((e, e[:-1][::-1] + e[-1:]))
                elif k == "CONC" and len(p) >= 5:
                    ok, mal = ej(p[3]), ej(p[4])
                    for e in ok: s._add(canto, e, 3, "oro")
                    s.pares["CONC"] += list(zip(ok, mal))
                elif k == "USO" and len(p) >= 6:
                    ok, mal = ej(p[4]), ej(p[5])
                    for e in ok: s._add(canto, e, 3, "oro")
                    s.pares["USO"] += [(ok[min(i, len(ok) - 1)], b) for i, b in enumerate(mal)]
                continue
            if l.startswith("#") or l.strip() in ("", "---") or not canto: continue
            l = re.sub(r"^\*\*[^*]+\*\*\s*", "", l.strip()).split("→")[0]
            for t in SD.frases(l): s._add(canto, t, 1, "prosa")
        # pares mínimos exactos de concordancia: cambiar SOLO el género del determinante (la niña → el niña)
        opuesto = {"el": "la", "la": "el", "un": "una", "una": "un", "los": "las", "las": "los", "unos": "unas", "unas": "unos",
                   "este": "esta", "esta": "este", "estos": "estas", "estas": "estos", "ese": "esa", "esa": "ese", "esos": "esas", "esas": "esos"}
        s.pares["CONCmin"] = []
        for _, t, _, _ in s.frases:
            for i in range(len(t) - 1):
                r = s.info(t[i + 1])[1]
                if t[i] in opuesto and ("m" in r or "f" in r) and t[i + 1] not in PUNT:
                    s.pares["CONCmin"].append((t, t[:i] + [opuesto[t[i]]] + t[i + 1:])); break
        # firma modal por categoría (para inicializar clases latentes)
        cnt = C.defaultdict(C.Counter)
        for w, e in s.lex.items():
            if e["firma"] != "?": cnt[e["cat"]][e["firma"]] += 1
        s.firma_cat = {c: v.most_common(1)[0][0] for c, v in cnt.items()}
        s.clases = sorted({e["firma"] for e in s.lex.values() if e["firma"] != "?"} | {"Ξ", "?"})
        s.pol = {c: pol(c) for c in s.clases}
        s.cat_firma = {}
        for c in s.clases:
            k = C.Counter(e["cat"] for e in s.lex.values() if e["firma"] == c)
            s.cat_firma[c] = k.most_common(1)[0][0] if k else "?"
    def _add(s, canto, t, peso, orig): s.frases.append((canto, t, peso, orig)); s.meta.append((s._sec, s._modo))
    def info(s, w):
        if w in PUNT: return ("PUNT", frozenset(), "Ξ")
        if w in s.lex: e = s.lex[w]; return (e["cat"], frozenset(e["r"]), e["firma"] if e["firma"] != "?" else None)
        if w in s.gen:
            l, c, r, _ = s.gen[w][0]; f = s.lex[l]["firma"] if l in s.lex and s.lex[l]["firma"] != "?" else None
            return (c, frozenset(r), f)
        return ("?", frozenset(), None)

# ───────────────────────── cuentas y modelo ─────────────────────────
class Cuentas:
    def __init__(s):
        s.U = C.Counter(); s.N = 0; s.V = set()
        s.B = {}; s.nB = C.Counter(); s.T = {}; s.nT = C.Counter()
        s.CF = {}; s.nCF = C.Counter(); s.EF = {}; s.nEF = C.Counter()
        s.CS = {}; s.nCS = C.Counter(); s.ES = {}; s.nES = C.Counter(); s.cache = {}; s.top = {}
    @staticmethod
    def _inc(tab, k, v, peso):
        d = tab.get(k)
        if d is None: d = tab[k] = C.Counter()
        d[v] += peso

class Semilla:
    def __init__(s, M):
        s.M = M; s.kappa = 0.0; s.alpha = 4.0; s.a = 1.0; s.m = [.15, .2, .25, .2, .2]; s.LAT = {}  # α: las reglas SINT/CONC del Madre se DAN como prior (no se ajustan por pérdida)
        s.Fs = M.clases
        for sents in [M.frases]:
            for _, t, _, _ in sents:
                for w in t:
                    if M.info(w)[2] is None and w not in s.LAT:
                        c = M.info(w)[0]; s.LAT[w] = M.firma_cat.get(c, "?")
        sts = {s.estado(w) for _, t, _, _ in M.frases for w in t} | {s.estado(w) for w in list(M.lex) + list(M.gen)}
        s.Ss = sorted(sts | {("?", None, None)}, key=str)
    def cf(s, w): return s.M.info(w)[2] or s.LAT.get(w, "?")
    def estado(s, w):
        c, r, f = s.M.info(w)
        if c == "?" : c = s.M.cat_firma.get(s.LAT.get(w, "?"), "?") if w in s.LAT else "?"
        g = "m" if "m" in r else ("f" if "f" in r else None)
        if g is None and "fx" in r: g = "m"                      # adjetivo en forma base (pequeño): masculino; su femenino se deriva por MORF
        n = "pl" if "pl" in r else ("sg" if (g or c == "N") else None)
        return (c, g, n)
    # ── cuentas con prior gramatical ──
    def construir(s, sents, excluir=None):
        cnt = Cuentas(); M = s.M
        for i, (cn, t, peso, _) in enumerate(sents):
            if excluir is not None and i % K_PLIEGUES == excluir: continue
            pp = p = "<s>"; cp = "<s>"; sp = "<s>"
            for w in t:
                c = s.cf(w); st = s.estado(w); u = peso
                cnt.U[w] += u; cnt.N += u; cnt.V.add(w)
                Cuentas._inc(cnt.B, p, w, u); cnt.nB[p] += u; Cuentas._inc(cnt.T, (pp, p), w, u); cnt.nT[(pp, p)] += u
                Cuentas._inc(cnt.CF, cp, c, u); cnt.nCF[cp] += u; Cuentas._inc(cnt.EF, c, w, u); cnt.nEF[c] += u
                Cuentas._inc(cnt.CS, sp, st, u); cnt.nCS[sp] += u; Cuentas._inc(cnt.ES, st, w, u); cnt.nES[st] += u
                pp, p, cp, sp = p, w, c, st
        s._prior(cnt); return cnt
    def _prior(s, cnt):
        """Reglas SINT y CONC como pseudo-cuentas sobre transiciones de estados sintácticos (cat, género, número)."""
        if not s.alpha: return
        por = C.defaultdict(list)
        for st in s.Ss: por[st[0]].append(st)
        comp = lambda x, y: (x[1] is None or y[1] is None or x[1] == y[1]) and (x[2] is None or y[2] is None or x[2] == y[2])
        vistos = set()
        for _, pat in s.M.patrones:
            pat = [{"CONJ": "CONJ"}.get(c, c) for c in pat]
            for a, b in zip(["<s>"] + pat, pat):
                for sa in (por[a] if a != "<s>" else ["<s>"]):
                    for sb in por[b]:
                        if (sa, sb) in vistos or (sa != "<s>" and not comp(sa, sb)): continue
                        vistos.add((sa, sb)); Cuentas._inc(cnt.CS, sa, sb, s.alpha); cnt.nCS[sa] += s.alpha
    # ── distribuciones de clase (exactas), con atractor de flujo ──
    def dF(s, cnt, cp, f):
        fq = round(f * 2) / 2; k = ("F", cp, fq, s.kappa); r = cnt.cache.get(k)
        if r is None:
            row = cnt.CF.get(cp); n = cnt.nCF[cp]; nF = len(s.Fs); r = {}
            for c in s.Fs:
                v = ((row[c] if row else 0) + s.a / nF) / (n + s.a)
                if s.kappa: v *= math.exp(-s.kappa * (LAM * fq + s.M.pol[c]) ** 2 / 2)   # cancelación del desbalance
                r[c] = v
            z = sum(r.values()); r = {c: v / z for c, v in r.items()}; cnt.cache[k] = r
        return r
    def dS(s, cnt, sp):
        k = ("S", sp); r = cnt.cache.get(k)
        if r is None:
            row = cnt.CS.get(sp); n = cnt.nCS[sp]; nS = len(s.Ss)
            r = {st: ((row[st] if row else 0) + s.a / nS) / (n + s.a) for st in s.Ss}; cnt.cache[k] = r
        return r
    def comps(s, cnt, w, ctx, cw=None, sw=None):
        pp, p, cp, sp, f = ctx; a = s.a; u = (cnt.U[w] + .1) / (cnt.N + .1 * (len(cnt.V) + 5000))
        nb = cnt.nB[p]; b = ((cnt.B[p][w] if p in cnt.B else 0) + a * u) / (nb + a) if nb else u
        nt = cnt.nT[(pp, p)]; t = ((cnt.T[(pp, p)][w] if (pp, p) in cnt.T else 0) + a * b) / (nt + a) if nt else b
        c = cw or s.cf(w); st = sw or s.estado(w)
        pf = s.dF(cnt, cp, f)[c] * (((cnt.EF[c][w] if c in cnt.EF else 0) + a * u) / (cnt.nEF[c] + a))
        ps = s.dS(cnt, sp)[st] * (((cnt.ES[st][w] if st in cnt.ES else 0) + a * u) / (cnt.nES[st] + a))
        return (u, b, t, pf, ps)
    def prob(s, cnt, w, ctx): return sum(m * x for m, x in zip(s.m, s.comps(cnt, w, ctx)))
    def sig(s, w, ctx):
        pp, p, cp, sp, f = ctx; c = s.cf(w); return (p, w, c, s.estado(w), LAM * f + s.M.pol[c])
    def contextos(s, t):
        out = []; pp = p = "<s>"; cp = sp = "<s>"; f = 0.0
        for w in t:
            out.append((pp, p, cp, sp, f)); c = s.cf(w); f = LAM * f + s.M.pol[c]; pp, p, cp, sp = p, w, c, s.estado(w)
        return out
    def propuestas(s, cnt, ctx, rng):
        pp, p, cp, sp, f = ctx; S = set(cnt.B.get(p, ())) | set(cnt.T.get((pp, p), ()))
        for tab, dist, key in ((cnt.EF, s.dF(cnt, cp, f), "F"), (cnt.ES, s.dS(cnt, sp), "S")):
            for c in sorted(dist, key=dist.get, reverse=True)[:3]:
                top = cnt.top.get((key, c))
                if top is None: top = cnt.top[(key, c)] = [w for w, _ in tab[c].most_common(6)] if c in tab else []
                S.update(top)
        return S
    # ── evaluación de una posición: colapso retroactivo ──
    def posicion(s, cnt, t, ctxs, i, rng):
        w = t[i]; ctx = ctxs[i]; props = s.propuestas(cnt, ctx, rng); props.add(w); P = {x: s.prob(cnt, x, ctx) for x in props}
        lf = -math.log(P[w]); rank_f = 1 + sum(v > P[w] for v in P.values())
        tot = sum(P.values()) + max(1e-9, 1 - sum(P.values())); hpre = H([v / tot for v in list(P.values()) + [max(1e-9, 1 - sum(P.values()))]])
        if i + 1 >= len(t): return (lf, None, hpre, None, rank_f, None)
        r = t[i + 1]; num = {}
        for x in props: num[x] = P[x] * s.prob(cnt, r, s.sig(x, ctx))
        cola = max(1e-9, 1 - sum(P.values())); vocab = list(cnt.V - props)
        lt = [s.prob(cnt, r, s.sig(x, ctx)) for x in rng.sample(vocab, min(5, len(vocab)))] if vocab else [1e-6]
        ltm = sum(lt) / len(lt); Z = sum(num.values()) + cola * ltm
        lr = -math.log(num[w] / Z); rank_r = 1 + sum(v > num[w] for v in num.values())
        hpost = H([v / Z for v in list(num.values()) + [cola * ltm]])
        return (lf, lr, hpre, hpost, rank_f, rank_r)

# ───────────────────────── entrenamiento ─────────────────────────
def evaluar(S, sents, paso=1, seed=0, insample=False, pesos=None):
    """insample=True: MAESTRÍA del Madre (las cuentas incluyen todo el texto). False: generalización (5 pliegues, fuera de muestra)."""
    rng = random.Random(seed); R = C.defaultdict(list); viejo = S.m
    if pesos: S.m = pesos
    try:
        for k in (range(1) if insample else range(K_PLIEGUES)):
            cnt = S.construir(sents) if insample else S.construir(sents, excluir=k)
            for i, (cn, t, peso, _) in enumerate(sents):
                if (not insample and i % K_PLIEGUES != k) or len(t) < 2: continue
                ctxs = S.contextos(t)
                for j in range(0, len(t), paso):
                    lf, lr, hpre, hpost, rf, rr = S.posicion(cnt, t, ctxs, j, rng)
                    R["lf"].append(lf); R["hpre"].append(hpre); R["f1"].append(rf == 1); R["f5"].append(rf <= 5)
                    if lr is not None: R["lr"].append(lr); R["hpost"].append(hpost); R["r1"].append(rr == 1); R["r5"].append(rr <= 5)
    finally: S.m = viejo
    mean = lambda x: sum(x) / max(1, len(x))
    return {k: mean(v) for k, v in R.items()} | {"n": len(R["lf"])}

def colapsar_latentes(S, sents):
    """E-paso: la clase de cada palabra sin firma se colapsa con sus vecinos (izq y der).  P(c|cp,cr) ∝ P(c|cp)·P(cr|c)."""
    cnt = S.construir(sents); acum = C.defaultdict(lambda: C.Counter()); cambios = 0
    for _, t, peso, _ in sents:
        cl = [S.cf(w) for w in t]
        for i, w in enumerate(t):
            if S.M.info(w)[2] is not None or w in PUNT: continue
            cp = cl[i - 1] if i else "<s>"; cr = cl[i + 1] if i + 1 < len(t) else None
            c0 = S.M.firma_cat.get(S.M.info(w)[0]); cands = [c0] if c0 and S.M.info(w)[0] != "?" else [c for c in S.Fs if c not in ("?", "Ξ")]
            for c in cands:
                v = S.dF(cnt, cp, 0.0)[c]
                if cr is not None: v *= S.dF(cnt, c, 0.0)[cr]
                acum[w][c] += v * peso
    for w, q in acum.items():
        nuevo = q.most_common(1)[0][0]
        if S.LAT.get(w) != nuevo: cambios += 1; S.LAT[w] = nuevo
    return cambios

def ajustar_pesos(S, sents, m0, insample=False, iters=4, n=900, seed=1):
    """Pasos de EM de la mezcla [uni, bi, tri, firma-clase+flujo, sintáctica]. En muestra (maestría) o fuera de muestra (generalización)."""
    rng = random.Random(seed); filas = []
    for k in (range(1) if insample else range(K_PLIEGUES)):
        cnt = S.construir(sents) if insample else S.construir(sents, excluir=k)
        for i, (cn, t, peso, _) in enumerate(sents):
            if (not insample and i % K_PLIEGUES != k) or len(t) < 2: continue
            ctxs = S.contextos(t)
            for j in range(len(t)): filas.append(S.comps(cnt, t[j], ctxs[j]))
    rng.shuffle(filas); filas = filas[:n * 4]; m = list(m0)
    for _ in range(iters):
        acc = [0.0] * 5
        for c in filas:
            z = sum(a * b for a, b in zip(m, c))
            for k in range(5): acc[k] += m[k] * c[k] / z
        m = [0.98 * a / len(filas) + 0.02 / 5 for a in acc]
    return m

def elegir(S, sents, nombre, grilla, base):
    """Hiperparámetro por validación cruzada; solo se aparta de `base` si mejora la pérdida retroactiva en más de 0.01 nats."""
    res = {}
    for v in grilla: setattr(S, nombre, v); res[v] = evaluar(S, sents, paso=5)["lr"]
    mejor = min(res, key=res.get); setattr(S, nombre, mejor if res[base] - res[mejor] > 0.01 else base); return res

def entrenar(md, log=print):
    t0 = time.time(); M = Madre(md); S = Semilla(M); ncantos = max(c for c, *_ in M.frases)
    log(f"Madre: {len(M.frases)} frases ({sum(1 for f in M.frases if f[3]=='oro')} de oro), {sum(len(f[1]) for f in M.frases)} tokens, "
        f"{len(M.clases)} clases de firma, {len(S.Ss)} estados sintácticos, {len(M.patrones)} patrones SINT, {len(S.LAT)} palabras de clase latente")
    log("MAESTRÍA = dentro de muestra (el Madre aprendido)  |  GENERALIZACIÓN = 5 pliegues, fuera de muestra.  Varianza = entropía normalizada de la superposición de palabras.")
    S.mm = [.2] * 5; historia = []
    for canto in range(1, ncantos + 1):
        sents = [f for f in M.frases if f[0] <= canto]
        if len(sents) < K_PLIEGUES * 2: continue
        prev = None; quieto = 0
        for ep in range(1, 11):
            ch = colapsar_latentes(S, sents)                                   # colapso retroactivo de clases latentes
            S.mm = ajustar_pesos(S, sents, S.mm, insample=True)                # maestría
            S.m = ajustar_pesos(S, sents, S.m, insample=False)                 # generalización
            if ep in (1, 4): elegir(S, sents, "kappa", (0.0, 0.15, 0.4, 1.0), 0.0)   # atractor de flujo
            mi = evaluar(S, sents, paso=2, insample=True, pesos=S.mm); cv = evaluar(S, sents, paso=4)
            r = {"canto": canto, "ep": ep, "kappa": S.kappa, "alpha": S.alpha, "cambios": ch, "in": mi, "cv": cv, "mm": list(S.mm), "m": list(S.m)}; historia.append(r)
            log(f"canto {canto:2d} ép {ep:2d} | MAESTRÍA pérdida {mi['lf']:.3f} retro {mi['lr']:.3f} varianza {mi['hpre']:.3f}→{mi['hpost']:.3f} top5 {mi['r5']:.2f}"
                f" | GENERALIZACIÓN pérdida {cv['lf']:.3f} retro {cv['lr']:.3f} varianza {cv['hpre']:.3f}→{cv['hpost']:.3f} | κ={S.kappa} α={S.alpha} Δcl={ch}")
            if prev and abs(prev["in"]["lr"] - mi["lr"]) < 3e-3 and abs(prev["in"]["hpre"] - mi["hpre"]) < 3e-3: quieto += 1
            else: quieto = 0
            prev = r
            if quieto >= 2: break
    log(f"entrenamiento completo en {time.time()-t0:.0f}s")
    return S, M, historia

def puntuar(S, cnt, t):
    ctxs = S.contextos(t); return sum(math.log(S.prob(cnt, w, ctxs[j])) for j, w in enumerate(t)) / len(t)

def pruebas(S, M, log=print):
    """Pares mínimos fuera de muestra: ¿puntúa mejor la frase correcta que la incorrecta?  Con y sin prior gramatical."""
    idx = {tuple(t): i for i, (_, t, _, _) in enumerate(M.frases)}; res = {}
    for alpha in (S.alpha, 0.0):
        viejo = S.alpha; S.alpha = alpha; cache = {}
        for tipo, pares in M.pares.items():
            ok = n = 0
            for a, b in pares:
                i = idx.get(tuple(a), 0); k = i % K_PLIEGUES
                if k not in cache: cache[k] = S.construir(M.frases, excluir=k)
                n += 1; ok += puntuar(S, cache[k], a) > puntuar(S, cache[k], b)
            res[(tipo, alpha)] = (ok, n)
        S.alpha = viejo
    for tipo in M.pares:
        a, b = res[(tipo, S.alpha)], res[(tipo, 0.0)]
        log(f"pares mínimos {tipo:5s}: con reglas {a[0]}/{a[1]} ({a[0]/a[1]:.0%})   sin prior gramatical {b[0]}/{b[1]} ({b[0]/b[1]:.0%})")
    return res

def barrido(S, M, log=print):
    """Efecto del prior gramatical α sobre pérdida fuera de muestra y pares mínimos."""
    idx = {}
    for i, (_, t, _, _) in enumerate(M.frases): idx.setdefault(tuple(t), i)
    viejo = S.alpha
    for a in (0, 1, 4, 16, 64):
        S.alpha = a; cv = evaluar(S, M.frases, paso=3); out = []; cache = {}
        for tipo, pares in M.pares.items():
            ok = 0
            for x, y in pares:
                k = idx.get(tuple(x), 0) % K_PLIEGUES
                if k not in cache: cache[k] = S.construir(M.frases, excluir=k)
                ok += puntuar(S, cache[k], x) > puntuar(S, cache[k], y)
            out.append(f"{tipo} {ok}/{len(pares)}")
        log(f"α={a:>3}: pérdida fuera de muestra {cv['lf']:.3f} retro {cv['lr']:.3f} | " + " · ".join(out))
    S.alpha = viejo

def guardar(S, historia, ruta):
    """Estado de la semilla en datos planos (sin clases): cuentas del Madre completo + parámetros aprendidos."""
    cnt = S.construir(S.M.frases)
    estado = {"kappa": S.kappa, "alpha": S.alpha, "pesos_maestria": S.mm, "pesos_generalizacion": S.m, "clases_latentes": S.LAT,
              "cuentas": {k: v for k, v in vars(cnt).items() if k not in ("cache", "top")}, "historia": historia}
    pickle.dump(estado, open(ruta, "wb"))

def cargar(md, ruta):
    """Reconstruye la semilla entrenada: S, cuentas completas (listas para predecir/continuar el entrenamiento)."""
    e = pickle.load(open(ruta, "rb")); M = Madre(md); S = Semilla(M)
    S.kappa, S.alpha, S.mm, S.m, S.LAT = e["kappa"], e["alpha"], e["pesos_maestria"], e["pesos_generalizacion"], e["clases_latentes"]
    cnt = Cuentas(); cnt.__dict__.update(e["cuentas"]); cnt.cache = {}; cnt.top = {}; return S, cnt

if __name__ == "__main__":
    a = [x for x in sys.argv[1:] if not x.startswith("--")]
    md = a[0] if a else os.path.join(AQUI, "TEXTO_MADRE_DELTA_v5.md")
    S, M, h = entrenar(md); pruebas(S, M)
    if "--barrido" in sys.argv: print(); barrido(S, M)
    guardar(S, h, os.path.join(AQUI, "semilla_R.pkl")); print("estado guardado: semilla_R.pkl")
