#!/usr/bin/env python3
"""MEMORIA HOLOGRÁFICA (HRR) — vectores de dimensión fija, convolución circular con numpy.fft.

Cada par (contexto → siguiente) se liga con convolución circular y se SUPERPONE en una sola traza:   M += ctx ⊛ siguiente
Se lee desenlazando con la correlación (inversa aproximada):                                       q = M ⊛⁻¹ ctx  ≈ siguiente + ruido
y se limpia comparando con los vectores del vocabulario (coseno).  Dos niveles anidados (sombras de la misma frase):
  L0 palabras  ·  L1 estado sintáctico (categoría, género, número).  El nivel grueso generaliza lo que el fino no vio.
La capacidad es finita: con más pares que ~D la lectura se degrada (se mide en evaluar())."""
import hashlib, numpy as np

def _unit(x): n = np.linalg.norm(x); return x / n if n else x
class HRR:
    def __init__(s, D=1024, orden=2, nivel=lambda w: w, semilla=7):
        s.D, s.orden, s.nivel = D, orden, nivel
        r = np.random.default_rng(semilla); s.roles = [_unit(r.standard_normal(D)) for _ in range(orden)]
        s.vec, s.tr, s.n, s._mat, s._sim = {}, np.zeros(D), 0, None, []
    def v(s, x):
        if x not in s.vec:
            seed = int(hashlib.md5(x.encode("utf8")).hexdigest()[:12], 16)
            s.vec[x] = _unit(np.random.default_rng(seed).standard_normal(s.D)); s._mat = None
        return s.vec[x]
    def lig(s, a, b): return np.fft.irfft(np.fft.rfft(a) * np.fft.rfft(b), n=s.D)
    def ctx(s, hist):
        h = ([s.nivel("<s>")] * s.orden + [s.nivel(w) for w in hist])[-s.orden:]
        return sum(s.lig(s.roles[k], s.v(x)) for k, x in enumerate(reversed(h)))
    def guarda(s, hist, sig):
        s.tr += s.lig(s.ctx(hist), s.v(s.nivel(sig))); s.n += 1
    def lee(s, hist):
        c = s.ctx(hist); return np.fft.irfft(np.fft.rfft(s.tr) * np.conj(np.fft.rfft(c)), n=s.D)
    def _matriz(s):
        if s._mat is None or len(s._sim) != len(s.vec): s._sim = list(s.vec); s._mat = np.stack([s.vec[x] for x in s._sim])
        return s._mat, s._sim
    def puntua(s, hist, k=5):
        """top-k (símbolo, coseno) de este nivel."""
        q = s.lee(hist); M, sim = s._matriz(); nq = np.linalg.norm(q) or 1.0; c = M @ q / nq
        i = np.argsort(-c)[:k]; return [(sim[j], float(c[j])) for j in i]
    def entrena(s, frases):
        for t in frases:
            for i in range(len(t)): s.guarda(t[:i], t[i])

class MemoriaFractal:
    """Dos trazas anidadas (palabra, clase).  puntua() devuelve candidatas con el voto del nivel fino reforzado por el grueso."""
    def __init__(s, estado, D=1024, orden=2):
        s.estado = estado; s.L0 = HRR(D, orden); s.L1 = HRR(D, orden, nivel=estado)
    def entrena(s, frases): s.L0.entrena(frases); s.L1.entrena(frases)
    def puntua(s, hist, k=5):
        a = s.L0.puntua(hist, k); b = s.L1.puntua(hist, 1)
        return {"palabras": a, "clase": b[0] if b else None}

def evaluar(frases, estado, D=1024, orden=2, pliegues=5, tope=400):
    """Acierto fuera de muestra: se guardan 4/5 de las frases y se lee el 1/5 restante.  Línea base: tabla exacta del mismo orden."""
    import collections as C, random
    tr = [t for i, t in enumerate(frases) if i % pliegues]; te = [t for i, t in enumerate(frases) if i % pliegues == 0]
    H = HRR(D, orden); H.entrena(tr); tab = C.defaultdict(C.Counter)
    for t in tr:
        for i in range(len(t)): tab[tuple((["<s>"] * orden + t[:i])[-orden:])][t[i]] += 1
    a1 = a5 = b1 = b5 = n = 0; vocab = set(w for t in tr for w in t)
    for t in te:
        for i in range(len(t)):
            if t[i] not in vocab or n >= tope: continue
            top = [w for w, _ in H.puntua(t[:i], 5)]; a1 += top[0] == t[i]; a5 += t[i] in top
            c = tab.get(tuple((["<s>"] * orden + t[:i])[-orden:])); mc = [w for w, _ in c.most_common(5)] if c else []
            b1 += bool(mc) and mc[0] == t[i]; b5 += t[i] in mc; n += 1
    return {"n": n, "hrr_top1": a1 / n, "hrr_top5": a5 / n, "tabla_top1": b1 / n, "tabla_top5": b5 / n, "pares_guardados": H.n, "D": D}
