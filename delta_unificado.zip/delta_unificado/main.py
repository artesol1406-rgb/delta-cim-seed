#!/usr/bin/env python3
"""python main.py  — la semilla respira en la terminal.  Escribe una frase (usa ▢ para dejar un hueco) y mira qué predice, espera o colapsa."""
import sys
from nucleo import Delta
AYUDA = """  frase            procesa la frase (▢ = hueco que se colapsa hacia atrás con lo que viene después)
  :tau 0.5         umbral de certeza para predecir (por defecto 0.90)
  :crecer ruta     inyecta un archivo de texto (plasticidad: la semilla aprende sin cerrarse)
  :aprende frase   la frase se integra a la memoria
  :estado          resumen   ·   :hrr   acierto de la memoria holográfica fuera de muestra   ·   :salir"""
ICON = {"predice": "●", "predice_clase": "◐", "abre": "○", "retro": "↶", "hueco": "▢", "puntuación": "·", "desconocida": "?"}
def mostrar(r):
    for f in r["tokens"]:
        if f["accion"] in ("puntuación", "desconocida"): continue
        top = " ".join(f"{w}:{p:.2f}" for w, p in f["top"]); extra = ""
        if f.get("retro"): extra = "  ↶ con lo que sigue: " + ", ".join(f["retro"])
        print(f"  {ICON[f['accion']]} {f['w']:<12} {f['accion']:<14} P={f['pw']:.2f} n_ef={f['neff']:<6} {f['estado']:<12} adelante: {top}{extra}")
        print(f"      HRR: {' '.join(w for w, _ in f['hrr'])}  [{'consenso' if f['consenso'] else 'difiere'}]")
    c = r["respuesta"]; print("  respuesta:", c["texto"] or "(nada: no hay certeza)", "" if not c["espera"] else f" … espera (P={c['espera']['pw']}, n_ef={c['espera']['neff']}, {c['espera']['estado']})")
def main():
    d = Delta(); print("Δ listo.  :ayuda para ver comandos.")
    while True:
        try: l = input("Yo> ").strip()
        except (EOFError, KeyboardInterrupt): print(); break
        if not l: continue
        if l in (":salir", ":q"): break
        if l == ":ayuda": print(AYUDA)
        elif l == ":estado": print(" ", d.estado())
        elif l == ":hrr": print(" ", {k: (round(v, 3) if isinstance(v, float) else v) for k, v in d.evaluar_hrr().items()})
        elif l.startswith(":tau"):
            try: d.tau = float(l.split()[1]); print("  τ =", d.tau)
            except (IndexError, ValueError): print("  uso: :tau 0.5")
        elif l.startswith(":crecer"):
            try: print(" ", d.crecer(open(l.split(None, 1)[1].strip(), encoding="utf8").read()))
            except (IndexError, OSError) as e: print("  no pude leer el archivo:", e)
        elif l.startswith(":aprende"): print(" ", d.crecer(l.split(None, 1)[1] if " " in l else ""))
        else: mostrar(d.procesar(l))
if __name__ == "__main__": main()
